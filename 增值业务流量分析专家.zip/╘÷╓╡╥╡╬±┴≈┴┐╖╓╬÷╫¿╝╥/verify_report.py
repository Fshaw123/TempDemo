# -*- coding: utf-8 -*-
"""验证 v6.1 报告内容质量"""
import re, os, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

report_path = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    '增值业务流量分析报告_2026年1月1日-3月25日.html'
)

with open(report_path, encoding='utf-8') as f:
    html = f.read()

print('报告文件大小:', os.path.getsize(report_path), 'bytes')
print()

# ── 深度评价段落数 ────────────────────────────────────────────────
eval_pat = re.compile(r'class="eval-box">(.*?)</div>', re.DOTALL)
eval_blocks = eval_pat.findall(html)
biz_names = ['高速宝','设备升级','延保','增购','注销新办','换车换牌','会员']
print('=== 深度评价段落数（期望每业务4段）===')
all_pass = True
for i, block in enumerate(eval_blocks):
    paras = re.findall(r'<p>(.*?)</p>', block, re.DOTALL)
    bn = biz_names[i] if i < len(biz_names) else str(i)
    plain0 = re.sub(r'<[^>]+>', '', paras[0] if paras else block)[:60]
    ok = len(paras) >= 4
    if not ok:
        all_pass = False
    print(f'  {"✅" if ok else "❌"} {bn}: {len(paras)}段  首段: {plain0}...')

print('深度评价全部4段结构:', '✅ PASS' if all_pass else '❌ FAIL')
print()

# ── 战略建议卡片 ──────────────────────────────────────────────────
sc = html.count('class="strategy-card"')
roi = html.count('class="roi-tag"')
print(f'战略卡片数: {sc}（期望4）{"✅" if sc==4 else "❌"}')
print(f'ROI标签数:  {roi}（期望4）{"✅" if roi==4 else "❌"}')
print()

# ── 行动计划 ─────────────────────────────────────────────────────
p0 = html.count('badge-p0')
p1 = html.count('badge-p1')
p2 = html.count('badge-p2')
print(f'行动计划: P0={p0} P1={p1} P2={p2}')
print(f'  P0≤3: {"✅" if p0<=3 else "❌"}  P1≤5: {"✅" if p1<=5 else "❌"}  P2≤3: {"✅" if p2<=3 else "❌"}')
print(f'  P0至少1项: {"✅" if p0>=1 else "❌"}')
print()

# ── 第六部分存在 ──────────────────────────────────────────────────
has6 = '第六部分：战略建议与行动计划' in html
print(f'第六部分: {"✅" if has6 else "❌"}')

# ── 数值一致性 ────────────────────────────────────────────────────
print()
print('=== 数值一致性抽查 ===')
checks = [
    ('总毛利 1934.4万', '1934.4万'),
    ('净增 158.65万',   '158.65万'),
    ('高速宝 +87.03万', '+87.03万'),
    ('会员 -72.33万',   '-72.33万'),
    ('访问毛利价值 ¥1.84', '¥1.84'),
]
for label, val in checks:
    ok = val in html
    print(f'  {"✅" if ok else "❌"} {label}')

# ── 版本号 ────────────────────────────────────────────────────────
print()
print('版本号:', '✅ v6.1' if 'v6.1' in html else '❌ 未找到v6.1')

# ── 打印高速宝评价样本 ────────────────────────────────────────────
print()
print('=== 高速宝深度评价（纯文本前350字）===')
if eval_blocks:
    sample = re.sub(r'<[^>]+>', '', eval_blocks[0])
    print(sample[:350])
