# -*- coding: utf-8 -*-
"""
增值业务流量分析报告生成器 v6.0
====================================
将 full_analysis_by_date_range() 的结果生成与 cases/报告案例.html 同等质量的HTML报告。

用法：
    from scripts.analysis_core import TrafficAnalysis
    from generate_report import generate_html_report

    analyzer = TrafficAnalysis('增值业务流量转化明细表.xlsx')
    results  = analyzer.full_analysis_by_date_range(
        period1_year=2026, period1_months=[1,2,3],
        period1_start_day=1, period1_end_day=25,
        period2_year=2025, period2_months=[1,2,3],
        period2_start_day=1, period2_end_day=25,
        period1_name='2026年', period2_name='2025年'
    )
    generate_html_report(results, output_path='report.html')
"""

import json
import statistics
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scripts.analysis_core import BUSINESSES


# ══════════════════════════════════════════════════════════════════
# 工具函数
# ══════════════════════════════════════════════════════════════════

def _chg(a, b):
    """计算变化率（%）"""
    return (a - b) / b * 100 if b != 0 else 0


def _pp(a, b):
    """计算pp差值"""
    return a - b


def _fmt_wan(v):
    """格式化为X.X万"""
    return f"{v / 10000:.1f}"


def _fmt_wan2(v):
    """格式化为X.XX万"""
    return f"{v / 10000:.2f}"


def _pct_arrow(v):
    """带箭头的百分比变化"""
    if v > 0:
        return f'<span class="pos">▲{abs(v):.2f}%</span>'
    if v < 0:
        return f'<span class="neg">▼{abs(v):.2f}%</span>'
    return '<span class="neu">—</span>'


def _pp_arrow(v):
    """带箭头的pp变化"""
    if v > 0.005:
        return f'<span class="pos">▲{abs(v):.2f}pp</span>'
    if v < -0.005:
        return f'<span class="neg">▼{abs(v):.2f}pp</span>'
    return '<span class="neu">—</span>'


# ══════════════════════════════════════════════════════════════════
# 各业务指标提取
# ══════════════════════════════════════════════════════════════════

def _biz_meta(biz, p1, p2):
    days = int(p1['天数'])
    return dict(
        profit1=p1[f'{biz}毛利'],   profit2=p2[f'{biz}毛利'],
        uv1=p1[f'{biz}uv'],         uv2=p2[f'{biz}uv'],
        inflow1=p1[f'{biz}流入率'], inflow2=p2[f'{biz}流入率'],
        conv1=p1[f'{biz}转化率'],   conv2=p2[f'{biz}转化率'],
        price1=p1[f'{biz}客单价'],  price2=p2[f'{biz}客单价'],
        uvval1=p1[f'{biz}uv毛利价值'], uvval2=p2[f'{biz}uv毛利价值'],
        margin1=p1[f'{biz}毛利率'], margin2=p2[f'{biz}毛利率'],
        profit_chg=_chg(p1[f'{biz}毛利'], p2[f'{biz}毛利']),
        daily_p=p1[f'{biz}毛利'] / days / 10000,
        daily_u=p1[f'{biz}uv'] / days / 10000,
        days=days,
    )


def _lmdi(biz, results):
    attr = results['attribution_results'][biz]
    total = attr['总变化']
    uv_c, conv_c, price_c, marg_c = (
        attr['UV变化贡献'], attr['转化率变化贡献'],
        attr['客单价变化贡献'], attr['毛利率变化贡献']
    )
    def pct(v):
        return v / abs(total) * 100 if abs(total) > 0.01 else 0
    return dict(
        total=total, uv=uv_c, conv=conv_c, price=price_c, marg=marg_c,
        uv_pct=pct(uv_c), conv_pct=pct(conv_c),
        price_pct=pct(price_c), marg_pct=pct(marg_c),
    )


# ══════════════════════════════════════════════════════════════════
# 趋势图概况生成（第八节规范）
# ══════════════════════════════════════════════════════════════════

def _mk_trend_summaries(p1, p2, biz):
    """按SKILL.md第八节规范生成5条趋势图概况"""
    m = _biz_meta(biz, p1, p2)
    uvval_median = statistics.median([p1[f'{b}uv毛利价值'] for b in BUSINESSES])

    # ── 毛利图 ──────────────────────────────────────────────────
    pct = m['profit_chg']
    d   = '增长' if pct > 0 else '下降'
    if   pct > 50:  tail = '处于爆发式增长阶段，需持续观察变现效率能否同步跟上。'
    elif pct > 15:  tail = '增速健康，是本期重要的毛利贡献来源。'
    elif pct > 10:  tail = '增速稳健，是本期毛利规模较大的贡献业务。'
    elif pct > 0:   tail = '增速温和，整体趋势向好但动能有限。'
    elif pct > -5:  tail = '轻微下滑，需关注驱动因子是否持续恶化。'
    else:           tail = '下滑明显，是本期核心拖累来源，需优先干预。'
    profit_s = f'日均毛利¥{m["daily_p"]:.2f}万，同比{d}{abs(pct):.1f}%。{tail}'

    # ── UV图 ──────────────────────────────────────────────────
    uv_pct = _chg(m['uv1'], m['uv2'])
    uvv_pct = _chg(m['uvval1'], m['uvval2'])
    d   = '增长' if uv_pct > 0 else '下降'
    if   uv_pct > 20 and uvv_pct > 0:    tail = '流量规模扩大的同时变现效率也在提升，属于健康扩张。'
    elif uv_pct > 20 and uvv_pct < -10:   tail = f'流量大幅增长但UV毛利价值下降{abs(uvv_pct):.0f}%，新增流量变现效率偏低，需排查流量质量。'
    elif uv_pct > 5  and uvv_pct >= 0:    tail = '流量稳步扩大，变现效率同步改善，增长质量良好。'
    elif uv_pct > 0  and uvv_pct < 0:     tail = '流量有所增长，但变现效率下滑，需关注流量质量是否在稀释。'
    elif uv_pct < -5:                      tail = '流量规模收缩，若变现效率能同步提升可部分对冲影响。'
    else:                                  tail = '流量规模基本稳定。'
    uv_s = f'日均UV{m["daily_u"]:.2f}万，同比{d}{abs(uv_pct):.1f}%。{tail}'

    # ── UV毛利价值图 ─────────────────────────────────────────
    v1  = m['uvval1']
    d   = '提升' if uvv_pct > 0 else '下降'
    if   v1 >  uvval_median and uvv_pct > 0:  tail = f'变现效率处于全场中上水平（全场中位数¥{uvval_median:.2f}），且仍在提升，变现能力持续增强。'
    elif v1 >  uvval_median and uvv_pct <= 0: tail = f'变现效率仍处全场中上水平（全场中位数¥{uvval_median:.2f}），但在下滑，需防止持续恶化。'
    elif abs(v1 - uvval_median) < 0.05 and uvv_pct > 0: tail = f'变现效率恰处全场中位水平（¥{uvval_median:.2f}），且提升速度达{abs(uvv_pct):.0f}%，变现能力改善明显。'
    elif v1 <  uvval_median and uvv_pct > 0:  tail = f'变现效率低于全场中位数（¥{uvval_median:.2f}），虽在提升，仍有较大提升空间。'
    else:                                      tail = f'变现效率低于全场中位数（¥{uvval_median:.2f}），且持续下降，是本业务最需关注的核心问题。'
    uvval_s = f'UV毛利价值¥{v1:.2f}，同比{d}{abs(uvv_pct):.1f}%。{tail}'

    # ── 客单价图 ─────────────────────────────────────────────
    pr_pct   = _chg(m['price1'], m['price2'])
    conv_chg = m['conv1'] - m['conv2']
    d        = '提升' if pr_pct > 0 else '下降'
    if   pr_pct > 3  and conv_chg >= 0:                           tail = '客单价提升且转化率未下滑，说明用户接受度良好，定价策略有效。'
    elif pr_pct > 3  and conv_chg < -0.1:                         tail = f'客单价提升但转化率下滑{abs(conv_chg):.2f}pp，部分价格敏感用户流失，需平衡提价幅度与转化率。'
    elif pr_pct < -5 and conv_chg > 0 and m['profit_chg'] > 0:    tail = f'客单价下降但转化率+{conv_chg:.2f}pp且毛利整体增长，属于结构性优化而非以价换量。'
    elif pr_pct < -5 and conv_chg > 0 and m['profit_chg'] <= 0:   tail = '降价换转化率但毛利未能改善，需重新评估定价策略。'
    elif pr_pct < -5 and conv_chg <= 0:                            tail = '客单价和转化率同步下滑，是双重变现压力，需优先排查原因。'
    elif abs(pr_pct) <= 3:                                         tail = '客单价基本稳定，定价策略波动不大。'
    else:                                                          tail = '客单价小幅变动，影响有限。'
    price_s = f'客单价¥{m["price1"]:.2f}，同比{d}{abs(pr_pct):.1f}%。{tail}'

    # ── 流入率图 ──────────────────────────────────────────────
    pp_val = m['inflow1'] - m['inflow2']
    d      = '提升' if pp_val > 0 else '下降'
    if   pp_val > 0.5 and uvv_pct > 0:    tail = '入口吸引力增强，且变现效率同步提升，流量结构健康。'
    elif pp_val > 0.5 and uvv_pct < -10:  tail = f'入口流量增多，但UV毛利价值下降{abs(uvv_pct):.0f}%，新进入的用户变现效率偏低，需优化流量结构。'
    elif pp_val > 0   and abs(uvv_pct) <= 10: tail = '入口吸引力小幅增强，变现效率基本稳定。'
    elif pp_val < -0.5:                    tail = '入口流量减少，需评估是自然波动还是入口竞争力下降。'
    else:                                  tail = '流入率基本稳定，入口竞争力无明显变化。'
    inflow_s = f'流入率{m["inflow1"]:.2f}%，同比{d}{abs(pp_val):.2f}pp。{tail}'

    return dict(profit=profit_s, uv=uv_s, uvval=uvval_s, price=price_s, inflow=inflow_s)


# ══════════════════════════════════════════════════════════════════
# 四象限计算（第十二节规范）
# ══════════════════════════════════════════════════════════════════

def _calc_quadrants(p1, p2):
    growths = {b: _chg(p1[f'{b}毛利'], p2[f'{b}毛利']) for b in BUSINESSES}
    shares  = {b: p1[f'{b}毛利'] / p1['总毛利'] * 100 for b in BUSINESSES}
    g_med = statistics.median(list(growths.values()))
    s_med = statistics.median(list(shares.values()))

    quads = {'star': [], 'rising': [], 'cow': [], 'problem': []}
    for b in BUSINESSES:
        g, s = growths[b], shares[b]
        if   g >= g_med and s >= s_med: quads['star'].append((b, g, s))
        elif g >= g_med and s <  s_med: quads['rising'].append((b, g, s))
        elif g <  g_med and s >= s_med: quads['cow'].append((b, g, s))
        else:                           quads['problem'].append((b, g, s))
    return quads, g_med, s_med


def _biz_list_html(items):
    if not items:
        return '<div style="font-size:12px;color:var(--ts)">（本期无）</div>'
    rows = []
    for biz, g, s in items:
        arrow = '▲' if g >= 0 else '▼'
        color = '#2E7D32' if g >= 0 else '#C62828'
        rows.append(
            f'<div class="matrix-biz-item">'
            f'<strong>{biz}</strong>'
            f'&ensp;增长率&nbsp;<span style="color:{color};font-weight:700">{arrow}{abs(g):.1f}%</span>'
            f'&ensp;毛利占比&nbsp;<span style="font-weight:600">{s:.1f}%</span>'
            f'</div>'
        )
    return '\n'.join(rows)


# ══════════════════════════════════════════════════════════════════
# 增长模式分类（第十一节规范，优先级判定）
# ══════════════════════════════════════════════════════════════════

def _growth_mode(biz, p1, p2):
    """按优先级判定增长模式"""
    profit_chg = _chg(p1[f'{biz}毛利'], p2[f'{biz}毛利'])
    uv_chg     = _chg(p1[f'{biz}uv'], p2[f'{biz}uv'])
    uvval_chg  = _chg(p1[f'{biz}uv毛利价值'], p2[f'{biz}uv毛利价值'])
    uvval_abs  = p1[f'{biz}uv毛利价值']
    conv_chg   = p1[f'{biz}转化率'] - p2[f'{biz}转化率']
    price_chg  = _chg(p1[f'{biz}客单价'], p2[f'{biz}客单价'])
    uvval_median = statistics.median([p1[f'{b}uv毛利价值'] for b in BUSINESSES])

    # 优先级1：全面收缩型
    if profit_chg < -10 and conv_chg < 0 and price_chg < 0:
        return '全面收缩型'
    # 优先级2：流量虚增型
    if uv_chg > 30 and uvval_chg < -15:
        return '流量虚增型'
    # 优先级3：规模扩张期
    if uv_chg > 20 and uvval_abs < uvval_median:
        return '规模扩张期'
    # 优先级4：量质齐升
    if uv_chg > 5 and uvval_abs >= uvval_median and uvval_chg > 0:
        return '量质齐升'
    # 优先级5：效率驱动
    if abs(uv_chg) <= 10 and (price_chg > 3 or p1[f'{biz}毛利率'] > p2[f'{biz}毛利率'] + 2) and profit_chg > 0:
        return '效率驱动'
    return '混合型'


# ══════════════════════════════════════════════════════════════════
# LMDI条形图HTML
# ══════════════════════════════════════════════════════════════════

def _lmdi_bar(val, total):
    pct   = min(100, abs(val / total * 100)) if abs(total) > 0.01 else 0
    color = '#2E7D32' if val >= 0 else '#C62828'
    return (f'<div style="height:6px;background:#eee;border-radius:3px;margin-top:4px">'
            f'<div style="width:{pct:.0f}%;height:100%;background:{color};border-radius:3px"></div></div>')


# ══════════════════════════════════════════════════════════════════
# 趋势数据序列化
# ══════════════════════════════════════════════════════════════════

def _build_trend_json(results):
    td  = results['trend_data']
    out = {}
    for biz in BUSINESSES:
        bdata = td[biz]
        out[biz] = {}
        for gran in ['day', 'week', 'month']:
            p1d, p2d = bdata['period1'][gran], bdata['period2'][gran]
            out[biz][gran] = {
                'labels1': p1d['labels'], 'labels2': p2d['labels'],
                'profit1': [round(v / 10000, 2) for v in p1d['profit_values']],
                'profit2': [round(v / 10000, 2) for v in p2d['profit_values']],
                'uv1':     [round(v / 10000, 2) for v in p1d['uv_values']],
                'uv2':     [round(v / 10000, 2) for v in p2d['uv_values']],
                'uvval1':  p1d['uv_value_per_uv'], 'uvval2': p2d['uv_value_per_uv'],
                'price1':  p1d['avg_price'],        'price2': p2d['avg_price'],
                'inflow1': p1d['inflow_rate'],       'inflow2': p2d['inflow_rate'],
            }
    return json.dumps(out, ensure_ascii=False)


# ══════════════════════════════════════════════════════════════════
# 7维度指标表行
# ══════════════════════════════════════════════════════════════════

def _row7(label, v2_str, v1_str, chg_html, direction, flag=''):
    return (f'<tr><td class="td-label">{label}</td>'
            f'<td>{v2_str}</td><td>{v1_str}</td>'
            f'<td>{chg_html}</td><td>{direction}</td>'
            f'<td>{flag}</td></tr>')


# ══════════════════════════════════════════════════════════════════
# 主生成函数
# ══════════════════════════════════════════════════════════════════

def generate_html_report(results: dict, output_path: str = None) -> str:
    """
    将 full_analysis_by_date_range() 的结果生成高质量HTML报告。

    参数：
        results     — analysis_core.py 返回的分析结果字典
        output_path — 输出文件路径（None则只返回HTML字符串）

    返回：
        HTML字符串
    """
    p1     = results['current_summary']
    p2     = results['previous_summary']
    td     = results['trend_data']
    params = results['analysis_params']
    DAYS   = int(p1['天数'])

    period1_name = params['period1']['name']
    period2_name = params['period2']['name']

    # ── 日期标题字符串 ──────────────────────────────────────────
    def _date_str(pinfo):
        y, m_list = pinfo['year'], pinfo['months']
        sd, ed    = pinfo.get('start_day'), pinfo.get('end_day')
        if len(m_list) == 1:
            m = m_list[0]
            if sd and ed:
                return f"{y}年{m}月{sd}日-{ed}日"
            return f"{y}年{m}月"
        else:
            m_start, m_end = min(m_list), max(m_list)
            if sd and ed:
                return f"{y}年{m_start}月{sd}日-{m_end}月{ed}日"
            return f"{y}年{m_start}-{m_end}月"

    period1_str = _date_str(params['period1'])
    period2_str = _date_str(params['period2'])
    report_title = f"{period1_str} vs {period2_str.split('年')[0]}年同期"

    # ── 总体指标 ────────────────────────────────────────────────
    total_profit_chg  = _chg(p1['总毛利'], p2['总毛利'])
    visitor_chg       = _chg(p1['访问人数'], p2['访问人数'])
    uv_total_chg      = _chg(p1['总业务uv'], p2['总业务uv'])
    inflow_chg_total  = _pp(p1['总业务uv流入率'], p2['总业务uv流入率'])
    access_val_chg    = _chg(p1['访问毛利价值'], p2['访问毛利价值'])

    # ── 业务排序 ────────────────────────────────────────────────
    rank_df = results['business_ranking'].reset_index()
    pos_biz  = [(r['业务'], r['绝对变化'], r['变化率%']) for _, r in rank_df.iterrows() if r['绝对变化'] > 0]
    neg_biz  = [(r['业务'], r['绝对变化'], r['变化率%']) for _, r in rank_df.iterrows() if r['绝对变化'] < 0]
    pos_sum  = sum(v for _, v, _ in pos_biz)
    neg_sum  = sum(v for _, v, _ in neg_biz)
    net_chg  = p1['总毛利'] - p2['总毛利']
    top1     = pos_biz[0] if pos_biz else None

    # ── 趋势数据 ────────────────────────────────────────────────
    trend_json = _build_trend_json(results)

    # ── 四象限 ──────────────────────────────────────────────────
    quads, g_med, s_med = _calc_quadrants(p1, p2)

    # ══════════════════════════════════════════════════════════════
    # CSS 样式
    # ══════════════════════════════════════════════════════════════
    CSS = """
:root{--primary:#1B3A5C;--secondary:#5B7FA5;--accent:#E8724A;--bg:#F7F8FA;
      --success:#2E7D32;--warn:#E8724A;--tp:#1A1F36;--ts:#6E7891;--border:#DDE1E9;}
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;
     background:var(--bg);color:var(--tp);line-height:1.6;
     padding-left:240px;transition:padding-left .3s;}
.container{max-width:1200px;margin:0 auto;padding:40px 20px;}
header{background:#fff;padding:40px;border-radius:8px;margin-bottom:32px;border:1px solid var(--border);}
h1{font-size:32px;color:var(--primary);font-weight:700;margin-bottom:12px;
   padding-bottom:12px;border-bottom:3px solid var(--primary);}
.subtitle{font-size:16px;color:var(--ts);margin-bottom:8px;}
.time-hl{color:var(--accent);font-weight:600;}
.meta{font-size:12px;color:var(--ts);}
section{background:#fff;padding:32px 40px;border-radius:8px;margin-bottom:28px;border:1px solid var(--border);}
h2{font-size:22px;color:var(--primary);font-weight:700;padding-bottom:10px;
   border-bottom:2px solid var(--primary);margin-bottom:20px;}
h3{font-size:16px;color:var(--tp);margin:20px 0 12px;font-weight:600;}
.summary-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:24px;}
.metric-card{background:var(--bg);border:1px solid var(--border);border-radius:6px;
             padding:16px;text-align:center;}
.metric-card.highlight{background:var(--primary);color:#fff;border-color:var(--primary);}
.metric-card.highlight .metric-label,.metric-card.highlight .metric-sub{color:rgba(255,255,255,.75);}
.metric-label{font-size:12px;color:var(--ts);margin-bottom:6px;}
.metric-value{font-size:22px;font-weight:700;color:var(--primary);}
.metric-card.highlight .metric-value{color:#fff;}
.metric-sub{font-size:11px;color:var(--ts);margin-top:4px;}
.conclusion-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:20px;}
.conclusion-card{border-radius:6px;padding:16px;border-left:4px solid;}
.conclusion-card.overall{border-color:var(--primary);background:#EEF3F9;}
.conclusion-card.engine{border-color:#2E7D32;background:#E8F5E9;}
.conclusion-card.risk{border-color:#E8724A;background:#FFF3E0;}
.conclusion-card.quality{border-color:#5B7FA5;background:#E3F2FD;}
.conclusion-title{font-size:12px;font-weight:700;margin-bottom:6px;}
.conclusion-text{font-size:12px;line-height:1.6;}
.pos{color:#2E7D32;font-weight:600;} .neg{color:#C62828;font-weight:600;} .neu{color:var(--ts);}
.biz-card{border:1px solid var(--border);border-radius:8px;padding:24px;margin-bottom:24px;}
.biz-header{display:flex;align-items:center;justify-content:space-between;
            margin-bottom:16px;border-bottom:1px solid var(--border);padding-bottom:12px;}
.biz-name{font-size:18px;font-weight:700;color:var(--primary);}
.biz-badge{font-size:12px;padding:4px 10px;border-radius:20px;font-weight:600;}
.badge-explosive-growth{background:#FFF8E1;color:#F57F17;border:1px solid #FFCA28;}
.badge-fast-growth{background:#E8F5E9;color:#2E7D32;border:1px solid #66BB6A;}
.badge-decline{background:#FFEBEE;color:#C62828;border:1px solid #EF9A9A;}
.biz-profit{font-size:14px;color:var(--ts);}
table{width:100%;border-collapse:collapse;font-size:13px;}
th{background:var(--primary);color:#fff;padding:10px 12px;text-align:center;font-weight:600;}
td{padding:9px 12px;border-bottom:1px solid var(--border);text-align:center;}
tr:hover td{background:#F0F4F8;}
.td-label{text-align:left;font-weight:500;color:var(--tp);}
.trend-section{margin-top:20px;}
.gran-btns{display:flex;gap:8px;margin-bottom:12px;}
.gran-btn{padding:5px 14px;border:1px solid var(--border);border-radius:20px;font-size:12px;
          cursor:pointer;background:#fff;color:var(--ts);transition:all .2s;}
.gran-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
.chart-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;}
.chart-grid.five .chart-box:last-child{grid-column:span 2;max-width:50%;margin:0 auto;width:100%;}
.chart-box{background:var(--bg);border-radius:6px;padding:16px;border:1px solid var(--border);}
.chart-title{font-size:13px;font-weight:600;color:var(--tp);margin-bottom:8px;}
.chart-summary{font-size:11px;color:var(--ts);margin-top:8px;font-style:italic;}
canvas{max-height:180px;}
.lmdi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:12px;}
.lmdi-item{background:var(--bg);border-radius:6px;padding:12px;
           border:1px solid var(--border);text-align:center;}
.lmdi-factor{font-size:11px;color:var(--ts);margin-bottom:4px;}
.lmdi-value{font-size:15px;font-weight:700;}
.lmdi-pct{font-size:11px;color:var(--ts);margin-top:2px;}
.eval-box{font-size:13px;line-height:1.9;padding:16px 18px;background:var(--bg);
          border-radius:6px;border-left:3px solid var(--secondary);}
.pattern-card{border-radius:6px;padding:16px;margin-bottom:12px;border-left:4px solid;}
.pattern-high{border-color:#C62828;background:#FFEBEE;}
.pattern-mid{border-color:#E8724A;background:#FFF3E0;}
.pattern-title{font-size:14px;font-weight:700;margin-bottom:6px;}
.pattern-desc{font-size:13px;line-height:1.6;}
.matrix{display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:12px;margin-top:16px;}
.matrix-cell{border-radius:6px;padding:16px;border:1px solid var(--border);}
.matrix-cell.star{background:#FFF8E1;border-color:#FFCA28;}
.matrix-cell.cow{background:#E8F5E9;border-color:#66BB6A;}
.matrix-icon{font-size:20px;margin-bottom:6px;}
.matrix-title{font-size:14px;font-weight:700;margin-bottom:4px;}
.matrix-biz-item{font-size:12px;padding:5px 0;border-bottom:1px solid rgba(0,0,0,.07);}
.matrix-biz-item:last-child{border-bottom:none;}
.strategy-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;margin-top:16px;}
.strategy-card{border-radius:6px;padding:20px;border:1px solid var(--border);background:var(--bg);}
.strategy-icon{font-size:20px;margin-bottom:8px;}
.strategy-title{font-size:15px;font-weight:700;color:var(--primary);margin-bottom:8px;}
.strategy-text{font-size:13px;line-height:1.7;color:var(--tp);}
.roi-tag{display:inline-block;background:#E8F5E9;color:#2E7D32;font-size:11px;
         font-weight:600;padding:2px 8px;border-radius:10px;margin-top:8px;}
.driver-box{background:var(--bg);border-radius:6px;padding:16px;margin-top:16px;border:1px solid var(--border);}
.driver-items{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;}
.driver-item{background:#fff;border:1px solid var(--border);border-radius:6px;padding:8px 14px;font-size:12px;}
.driver-item.growth{border-left:3px solid #2E7D32;}
.driver-item.decline{border-left:3px solid #C62828;}
.badge-p0{background:#FFEBEE;color:#C62828;font-weight:700;padding:2px 8px;border-radius:10px;font-size:11px;}
.badge-p1{background:#FFF3E0;color:#E8724A;font-weight:700;padding:2px 8px;border-radius:10px;font-size:11px;}
.badge-p2{background:#E3F2FD;color:#1565C0;font-weight:700;padding:2px 8px;border-radius:10px;font-size:11px;}
footer{text-align:center;padding:20px;color:var(--ts);font-size:12px;}
/* TOC Sidebar */
.toc-sidebar{position:fixed;top:0;left:0;height:100vh;width:240px;background:#fff;
  border-right:1px solid var(--border);z-index:1000;display:flex;flex-direction:column;
  transition:width .3s;overflow:hidden;box-shadow:2px 0 8px rgba(0,0,0,.05);}
.toc-sidebar.collapsed{width:40px;}
.toc-header{display:flex;align-items:center;justify-content:space-between;
  padding:14px 12px 10px;border-bottom:1px solid var(--border);flex-shrink:0;min-height:48px;}
.toc-title{font-size:13px;font-weight:700;color:var(--primary);white-space:nowrap;}
.toc-toggle{background:none;border:1px solid var(--border);border-radius:4px;cursor:pointer;
  font-size:11px;padding:3px 8px;color:var(--ts);flex-shrink:0;transition:transform .3s;}
.toc-sidebar.collapsed .toc-toggle{transform:scaleX(-1);}
.toc-sidebar.collapsed .toc-title,.toc-sidebar.collapsed .toc-nav{display:none;}
.toc-nav{flex:1;overflow-y:auto;padding:10px 6px;display:flex;flex-direction:column;gap:2px;}
.toc-nav a{display:block;padding:6px 10px;border-radius:4px;font-size:12px;color:var(--tp);
  text-decoration:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:background .15s;}
.toc-nav a:hover,.toc-nav a.active{background:#EEF3F9;color:var(--primary);font-weight:600;}
.toc-nav a.toc-sub{padding-left:20px;font-size:11px;color:var(--ts);}
.toc-nav a.toc-sub:hover,.toc-nav a.toc-sub.active{background:#EEF3F9;color:var(--secondary);}
body.toc-collapsed{padding-left:40px;}
"""

    # ══════════════════════════════════════════════════════════════
    # 第一部分：核心摘要
    # ══════════════════════════════════════════════════════════════

    def _card(title, value, sub='', cls=''):
        return (f'<div class="metric-card {cls}">'
                f'<div class="metric-label">{title}</div>'
                f'<div class="metric-value">{value}</div>'
                + (f'<div class="metric-sub">{sub}</div>' if sub else '') +
                f'</div>')

    # 驱动分析行
    driver_items_html = ''
    for biz, chg_v, pct in sorted(pos_biz + neg_biz,
                                   key=lambda x: x[1], reverse=True):
        cls  = 'growth' if chg_v > 0 else 'decline'
        icon = '🚀' if pct > 50 else ('📈' if chg_v > 0 else ('⚠️' if chg_v == min(v for _, v, _ in neg_biz) else '▼'))
        sign = '+' if chg_v > 0 else ''
        driver_items_html += (f'<div class="driver-item {cls}">'
                              f'{icon} {biz} {pct:+.2f}% · 贡献{sign}{_fmt_wan2(chg_v)}万</div>')

    # 核心结论卡片（基于实际数据动态生成）
    # 整体表现
    overall_text = (f'总毛利同比增长<strong>{total_profit_chg:+.2f}%</strong>，'
                    f'净增+{_fmt_wan2(net_chg)}万。'
                    f'正增长{len(pos_biz)}个业务（贡献+{_fmt_wan2(pos_sum)}万），'
                    f'下滑{len(neg_biz)}个（拖累{_fmt_wan2(neg_sum)}万）。')

    # 增长引擎
    if top1:
        top_biz, top_chg, top_pct = top1
        top_share = top_chg / net_chg * 100 if net_chg != 0 else 0
        m_top = _biz_meta(top_biz, p1, p2)
        engine_text = (f'{top_biz}毛利{top_pct:+.2f}%，贡献+{_fmt_wan2(top_chg)}万，'
                       f'占净增量<strong>{top_share:.1f}%</strong>。'
                       f'UV{_chg(m_top["uv1"],m_top["uv2"]):+.1f}%、'
                       f'转化率{_pp(m_top["conv1"],m_top["conv2"]):+.2f}pp驱动。')
    else:
        engine_text = '本期无正增长业务。'

    # 关注风险（最大下滑业务）
    if neg_biz:
        worst = min(neg_biz, key=lambda x: x[1])
        w_biz, w_chg, w_pct = worst
        m_w = _biz_meta(w_biz, p1, p2)
        risk_text = (f'{w_biz}毛利{w_pct:.2f}%（{_fmt_wan2(w_chg)}万），'
                     f'客单价{_chg(m_w["price1"],m_w["price2"]):.1f}%+'
                     f'UV毛利价值{_chg(m_w["uvval1"],m_w["uvval2"]):.1f}%，'
                     f'变现能力显著弱化。')
    else:
        risk_text = '本期无明显下滑业务。'

    # 流量质量
    quality_text = (f'访问毛利价值从¥{p2["访问毛利价值"]:.2f}提升至¥{p1["访问毛利价值"]:.2f}'
                    f'（<strong>{access_val_chg:+.2f}%</strong>），'
                    f'流入率{inflow_chg_total:+.2f}pp，整体效率改善，'
                    f'但部分业务UV毛利价值恶化需关注。')

    sec1 = f"""
<section id="sec1">
  <h2>第一部分：核心摘要</h2>
  <div class="summary-grid">
    {_card('总毛利（'+period1_name+'）',
           f'<span style="color:var(--accent)">{_fmt_wan(p1["总毛利"])}万</span>',
           f'同比 {_pct_arrow(total_profit_chg)}', 'highlight')}
    {_card('访问人数', f'{_fmt_wan(p1["访问人数"])}万', f'同比 {_pct_arrow(visitor_chg)}')}
    {_card('流入率', f'{p1["总业务uv流入率"]:.2f}%', f'同比 {_pp_arrow(inflow_chg_total)}')}
    {_card('业务合计UV', f'{_fmt_wan(p1["总业务uv"])}万', f'同比 {_pct_arrow(uv_total_chg)}')}
    {_card('访问毛利价值', f'¥{p1["访问毛利价值"]:.2f}', f'同比 {_pct_arrow(access_val_chg)}')}
  </div>
  <div class="driver-box">
    <strong style="font-size:13px">📊 业务驱动分析</strong>
    <div class="driver-items">{driver_items_html}</div>
  </div>
  <div class="conclusion-grid">
    <div class="conclusion-card overall">
      <div class="conclusion-title">📊 整体表现</div>
      <div class="conclusion-text">{overall_text}</div>
    </div>
    <div class="conclusion-card engine">
      <div class="conclusion-title">🚀 增长引擎</div>
      <div class="conclusion-text">{engine_text}</div>
    </div>
    <div class="conclusion-card risk">
      <div class="conclusion-title">⚠️ 关注风险</div>
      <div class="conclusion-text">{risk_text}</div>
    </div>
    <div class="conclusion-card quality">
      <div class="conclusion-title">🎯 流量质量</div>
      <div class="conclusion-text">{quality_text}</div>
    </div>
  </div>
</section>"""

    # ══════════════════════════════════════════════════════════════
    # 第二部分：业务影响程度排序
    # ══════════════════════════════════════════════════════════════

    rank_rows_html = ''
    bg_map = {1: '#FFF8E1', 2: '#E8F5E9', 3: '#E8F5E9'}
    neg_bg = '#FFF3E0'
    worst_biz = min(neg_biz, key=lambda x: x[1])[0] if neg_biz else None

    for i, (_, row) in enumerate(rank_df.iterrows()):
        biz_name   = row['业务']
        p1_col = [c for c in rank_df.columns if period1_name in c and '毛利' in c]
        p2_col = [c for c in rank_df.columns if period2_name in c and '毛利' in c]
        p1v = (row[p1_col[0]] if p1_col else p1[f'{biz_name}毛利']) / 10000
        p2v = (row[p2_col[0]] if p2_col else p2[f'{biz_name}毛利']) / 10000
        chg_v = row['绝对变化'] / 10000
        chg_r = row['变化率%']
        share = row[[c for c in rank_df.columns if '占比' in c][0]] if any('占比' in c for c in rank_df.columns) else p1[f'{biz_name}毛利'] / p1['总毛利'] * 100

        rank = i + 1
        bg   = bg_map.get(rank, '#FFEBEE' if biz_name == worst_biz else ('#FFF3E0' if chg_v < 0 else '#fff'))
        c_cls = 'pos' if chg_v > 0 else 'neg'

        if rank == 1 and chg_v > 0:   label = '🚀最大增长引擎'
        elif rank == 2 and chg_v > 0: label = '📈第二大增长引擎'
        elif rank == 3 and chg_v > 0: label = '📈第三大增长引擎'
        elif chg_v > 0:               label = '正增长'
        elif biz_name == worst_biz:   label = '⚠️最大下滑业务'
        else:                         label = '下滑业务'

        rank_rows_html += f'''
      <tr style="background:{bg}">
        <td>{rank}</td><td class="td-label"><strong>{biz_name}</strong></td>
        <td>{p1v:.2f}万</td><td>{p2v:.2f}万</td>
        <td><strong><span class="{c_cls}">{chg_v:+.2f}万</span></strong></td>
        <td><span class="{c_cls}">{chg_r:+.2f}%</span></td>
        <td>{share:.2f}%</td>
        <td style="font-weight:600">{label}</td>
      </tr>'''

    sec2 = f"""
<section id="sec2">
  <h2>第二部分：业务影响程度排序</h2>
  <table>
    <thead><tr>
      <th>排名</th><th>业务</th>
      <th>{period1_name}毛利</th><th>{period2_name}毛利</th>
      <th>绝对变化</th><th>变化率</th><th>毛利占比</th><th>影响等级</th>
    </tr></thead>
    <tbody>{rank_rows_html}</tbody>
  </table>
</section>"""

    # ══════════════════════════════════════════════════════════════
    # 第三部分：各业务详细分析
    # ══════════════════════════════════════════════════════════════

    BIZ_ORDER   = list(rank_df['业务'])  # 按排序输出
    biz_cards   = []

    for biz in BIZ_ORDER:
        m   = _biz_meta(biz, p1, p2)
        ld  = _lmdi(biz, results)
        ts  = _mk_trend_summaries(p1, p2, biz)

        # 业务badge
        if m['profit_chg'] > 30:
            badge_cls, badge_lbl = 'badge-explosive-growth', '🚀 爆发式增长'
        elif m['profit_chg'] > 0:
            badge_cls, badge_lbl = 'badge-fast-growth', '📈 稳健增长'
        else:
            badge_cls, badge_lbl = 'badge-decline', '⚠️ 下滑业务'

        chg_cls = 'pos' if m['profit_chg'] > 0 else 'neg'

        # 7维度指标行
        conv_flag  = '<span style="color:#E8724A;font-size:11px">⚠️注意</span>' if m['conv1'] < m['conv2'] else ''
        uvval_flag = '<span style="color:#C62828;font-size:11px">盈利下降</span>' if m['uvval1'] < m['uvval2'] else ''

        rows7 = (
            _row7('UV', f'{_fmt_wan(m["uv2"])}万', f'{_fmt_wan(m["uv1"])}万',
                  _pct_arrow(_chg(m["uv1"],m["uv2"])),
                  '增长' if m["uv1"]>m["uv2"] else '下降') +
            _row7('流入率', f'{m["inflow2"]:.2f}%', f'{m["inflow1"]:.2f}%',
                  _pp_arrow(_pp(m["inflow1"],m["inflow2"])),
                  '上升' if m["inflow1"]>m["inflow2"] else '下降') +
            _row7('转化率', f'{m["conv2"]:.2f}%', f'{m["conv1"]:.2f}%',
                  _pp_arrow(_pp(m["conv1"],m["conv2"])),
                  '上升' if m["conv1"]>m["conv2"] else '下降', conv_flag) +
            _row7('客单价', f'¥{m["price2"]:.2f}', f'¥{m["price1"]:.2f}',
                  _pct_arrow(_chg(m["price1"],m["price2"])),
                  '增长' if m["price1"]>m["price2"] else '下降') +
            _row7('毛利', f'{_fmt_wan(m["profit2"])}万', f'{_fmt_wan(m["profit1"])}万',
                  _pct_arrow(m["profit_chg"]),
                  '增长' if m["profit1"]>m["profit2"] else '下降') +
            _row7('UV毛利价值', f'¥{m["uvval2"]:.2f}', f'¥{m["uvval1"]:.2f}',
                  _pct_arrow(_chg(m["uvval1"],m["uvval2"])),
                  '增长' if m["uvval1"]>m["uvval2"] else '下降', uvval_flag) +
            _row7('毛利率', f'{m["margin2"]:.0f}%', f'{m["margin1"]:.0f}%',
                  _pp_arrow(_pp(m["margin1"],m["margin2"])),
                  '上升' if m["margin1"]>m["margin2"] else '持平' if m["margin1"]==m["margin2"] else '下降')
        )

        # LMDI 4格卡片
        def _lcard(factor, val, pct_v):
            cls = 'pos' if val >= 0 else 'neg'
            return (f'<div class="lmdi-item">'
                    f'<div class="lmdi-factor">{factor}</div>'
                    f'<div class="lmdi-value {cls}">{val/10000:+.2f}万</div>'
                    f'<div class="lmdi-pct">{pct_v:+.1f}%占比</div>'
                    f'{_lmdi_bar(val, ld["total"])}</div>')

        lmdi_html = (f'<div class="lmdi-grid">'
                     f'{_lcard("UV变化贡献", ld["uv"], ld["uv_pct"])}'
                     f'{_lcard("转化率变化贡献", ld["conv"], ld["conv_pct"])}'
                     f'{_lcard("客单价变化贡献", ld["price"], ld["price_pct"])}'
                     f'{_lcard("毛利率变化贡献", ld["marg"], ld["marg_pct"])}'
                     f'</div>')

        # 深度综合评价（四段结构，换行符转<p>段落渲染）
        biz_analysis = results.get('business_analysis', {}).get(biz, {})
        eval_raw = biz_analysis.get('综合评价', '')
        if not eval_raw:
            eval_raw = f'{biz}业务毛利同比{m["profit_chg"]:+.2f}%，请基于LMDI归因和7维度指标进行深度分析。'
        # 将 \n\n 换行转为 <p> 段落（四段结构）
        eval_paras = [p.strip() for p in eval_raw.split('\n\n') if p.strip()]
        eval_text  = ''.join(f'<p>{p}</p>' for p in eval_paras)

        # 趋势图卡片
        def _chart_box(chart_id, title, summary_text):
            return (f'<div class="chart-box">'
                    f'<div class="chart-title">{title}</div>'
                    f'<canvas id="chart-{chart_id}-{biz}"></canvas>'
                    f'<div class="chart-summary">📌 {summary_text}</div>'
                    f'</div>')

        biz_card = f"""
  <div class="biz-card" id="biz-{biz}">
    <div class="biz-header">
      <div>
        <span class="biz-name">{biz}</span>
        <span class="biz-profit" style="margin-left:12px">
          {period1_name}毛利：{_fmt_wan2(m['profit1'])}万 | 日均：¥{m['daily_p']:.2f}万
        </span>
      </div>
      <div>
        <span class="biz-badge {badge_cls}">{badge_lbl}</span>
        &nbsp;<span style="font-size:14px;font-weight:700">
          <span class="{chg_cls}">{m['profit_chg']:+.2f}%</span>
        </span>
      </div>
    </div>

    <h3>7维度指标对比</h3>
    <table>
      <thead><tr>
        <th>指标</th><th>{period2_name}</th><th>{period1_name}</th>
        <th>变化</th><th>方向</th><th>标记</th>
      </tr></thead>
      <tbody>{rows7}</tbody>
    </table>

    <h3>LMDI-I量化归因分析</h3>
    <p style="font-size:12px;color:var(--ts);margin-bottom:10px">
      总毛利变化：<strong style="font-size:14px">
        <span class="{chg_cls}">{ld['total']/10000:+.2f}万</span>
      </strong>（各因子之和 = 总变化，无残差）
    </p>
    {lmdi_html}

    <div class="trend-section">
      <h3>业务趋势分析（日/周/月）</h3>
      <div class="gran-btns">
        <button class="gran-btn active" onclick="switchGran('{biz}','day',this)">按日</button>
        <button class="gran-btn" onclick="switchGran('{biz}','week',this)">按周</button>
        <button class="gran-btn" onclick="switchGran('{biz}','month',this)">按月</button>
      </div>
      <div class="chart-grid five">
        {_chart_box('profit', '毛利趋势（万元）', ts['profit'])}
        {_chart_box('uv', 'UV趋势（万人）', ts['uv'])}
        {_chart_box('uvval', 'UV毛利价值（元/人）', ts['uvval'])}
        {_chart_box('price', '客单价趋势（元）', ts['price'])}
        {_chart_box('inflow', '流入率趋势（%）', ts['inflow'])}
      </div>
    </div>

    <h3>深度综合评价</h3>
    <div class="eval-box">{eval_text}</div>
  </div>"""
        biz_cards.append(biz_card)

    sec3 = f"""
<section id="sec3">
  <h2>第三部分：各业务详细分析</h2>
  {''.join(biz_cards)}
</section>"""

    # ══════════════════════════════════════════════════════════════
    # 第四部分：反直觉模式汇总（自动+人工两层）
    # ══════════════════════════════════════════════════════════════

    pattern_cards = []

    # 第一层：系统检测结果
    for w in results.get('counter_intuitive_warnings', []):
        severity = w.get('严重程度', '中')
        cls = 'pattern-high' if severity == '高' else 'pattern-mid'
        pattern_cards.append(
            f'<div class="pattern-card {cls}">'
            f'<div class="pattern-title">【{severity}】{w["业务"]}：{w["模式"]}</div>'
            f'<div class="pattern-desc">{w["说明"]}。根因分析：{w.get("根因","")}。'
            f'建议：{w.get("建议","")}</div></div>'
        )

    # 第二层：人工补充检测（SKILL.md第十节规范）
    detected = {w['业务'] for w in results.get('counter_intuitive_warnings', [])}
    for biz in BUSINESSES:
        if biz in detected:
            continue
        uv_chg     = _chg(p1[f'{biz}uv'], p2[f'{biz}uv'])
        uvval_chg  = _chg(p1[f'{biz}uv毛利价值'], p2[f'{biz}uv毛利价值'])
        conv_chg   = p1[f'{biz}转化率'] - p2[f'{biz}转化率']
        price_chg  = _chg(p1[f'{biz}客单价'], p2[f'{biz}客单价'])
        profit_chg = _chg(p1[f'{biz}毛利'], p2[f'{biz}毛利'])

        if uv_chg > 30 and uvval_chg < -15:
            pattern_cards.append(
                f'<div class="pattern-card pattern-mid">'
                f'<div class="pattern-title">【中】{biz}：UV大涨+UV毛利价值下降（流量虚增）</div>'
                f'<div class="pattern-desc">UV增长{uv_chg:.0f}%，但UV毛利价值下降{abs(uvval_chg):.0f}%，'
                f'新增流量变现效率偏低，需排查流量来源质量。</div></div>'
            )
        if conv_chg > 0 and price_chg < -5 and profit_chg <= 0:
            pattern_cards.append(
                f'<div class="pattern-card pattern-mid">'
                f'<div class="pattern-title">【中】{biz}：转化率提升+客单价下降（以价换量）</div>'
                f'<div class="pattern-desc">转化率+{conv_chg:.2f}pp但客单价{price_chg:.1f}%，'
                f'且毛利未能改善，降价代价偏高。建议重新评估定价策略。</div></div>'
            )
        if profit_chg > 0 and profit_chg < 15 and uv_chg > 0 and uvval_chg < -10:
            pattern_cards.append(
                f'<div class="pattern-card pattern-mid">'
                f'<div class="pattern-title">【中】{biz}：毛利增长但变现效率恶化（依赖规模掩盖）</div>'
                f'<div class="pattern-desc">毛利增长{profit_chg:.1f}%，但UV毛利价值下降{abs(uvval_chg):.0f}%，'
                f'效率在恶化，当前增长不可持续。</div></div>'
            )
        if uv_chg > 0 and profit_chg < -5:
            pattern_cards.append(
                f'<div class="pattern-card pattern-high">'
                f'<div class="pattern-title">【高】{biz}：UV增长+毛利大幅下滑（来了不买）</div>'
                f'<div class="pattern-desc">UV增长{uv_chg:.1f}%，但毛利下滑{abs(profit_chg):.1f}%，'
                f'用户来了但变现效率大幅恶化，需优先排查根因。</div></div>'
            )

    # 检测多业务客单价同向下滑
    price_drops = [(b, _chg(p1[f'{b}客单价'], p2[f'{b}客单价']))
                   for b in BUSINESSES if _chg(p1[f'{b}客单价'], p2[f'{b}客单价']) < -5]
    if len(price_drops) >= 2:
        biz_list_str = '、'.join([f'{b}（{v:+.1f}%）' for b, v in price_drops])
        pattern_cards.append(
            f'<div class="pattern-card pattern-mid">'
            f'<div class="pattern-title">【中】系统性降价倾向：{len(price_drops)}个业务客单价同步下滑</div>'
            f'<div class="pattern-desc">{biz_list_str}。多业务客单价同向下行，'
            f'可能反映定价策略整体偏向促销，需排查是否存在系统性"降价换量"倾向。</div></div>'
        )

    if not pattern_cards:
        pattern_cards.append('<p style="color:var(--ts);font-size:13px">本期未发现明显反直觉模式。</p>')

    sec4 = f"""
<section id="sec4">
  <h2>第四部分：反直觉模式汇总</h2>
  {''.join(pattern_cards)}
</section>"""

    # ══════════════════════════════════════════════════════════════
    # 第五部分：整体洞察与建议
    # ══════════════════════════════════════════════════════════════

    # 增长模式分类
    mode_groups = {}
    for biz in BUSINESSES:
        mode = _growth_mode(biz, p1, p2)
        mode_groups.setdefault(mode, []).append(biz)

    mode_html = ''
    mode_order = ['全面收缩型','流量虚增型','规模扩张期','量质齐升','效率驱动','混合型']
    mode_labels = {
        '规模扩张期': '<strong>规模扩张期（变现待成熟）：</strong>',
        '量质齐升':   '<strong>量质齐升：</strong>',
        '效率驱动':   '<strong>效率驱动：</strong>',
        '流量虚增型': '<strong>流量虚增型：</strong>',
        '全面收缩型': '<strong>全面收缩型：</strong>',
        '混合型':     '<strong>其他：</strong>',
    }
    for mode in mode_order:
        bizs = mode_groups.get(mode, [])
        if bizs:
            mode_html += f'{mode_labels[mode]}{", ".join(bizs)}<br>\n        '

    # 穿透性判断
    healthy_modes = ['量质齐升', '效率驱动']
    problem_modes = ['流量虚增型', '全面收缩型']
    healthy_profit = sum(p1[f'{b}毛利'] for mode in healthy_modes for b in mode_groups.get(mode, []))
    problem_profit = sum(p1[f'{b}毛利'] for mode in problem_modes for b in mode_groups.get(mode, []))
    total_profit   = p1['总毛利']
    healthy_share  = healthy_profit / total_profit * 100 if total_profit > 0 else 0
    problem_share  = problem_profit / total_profit * 100 if total_profit > 0 else 0

    penetration = (f'账面增长{total_profit_chg:+.2f}%，但内部分化在加速。'
                   f'健康模式（量质齐升+效率驱动）覆盖{len(healthy_modes)}类业务，'
                   f'占毛利{healthy_share:.1f}%；'
                   f'问题模式（流量虚增+全面收缩）占毛利{problem_share:.1f}%。'
                   f'若不干预，下一周期增长压力将显著上升。')

    # 客单价趋势分析
    price_drops_all = [(b, _chg(p1[f'{b}客单价'], p2[f'{b}客单价']))
                       for b in BUSINESSES if _chg(p1[f'{b}客单价'], p2[f'{b}客单价']) < -3]
    price_rise_all  = [(b, _chg(p1[f'{b}客单价'], p2[f'{b}客单价']))
                       for b in BUSINESSES if _chg(p1[f'{b}客单价'], p2[f'{b}客单价']) > 3]

    if len(price_drops_all) >= 2:
        price_trend_html = (f'<strong>客单价（本期最值得关注的信号）：</strong>'
                            f'<strong>{len(price_drops_all)}个业务客单价同步下滑</strong>'
                            f'——' +
                            '、'.join([f'{b}（{v:+.1f}%）' for b, v in price_drops_all]) +
                            '。多业务客单价同向下行，可能反映系统性降价倾向，需排查根因。')
    elif price_drops_all:
        b0, v0 = price_drops_all[0]
        price_trend_html = f'<strong>客单价：</strong>{b0}客单价下滑{abs(v0):.1f}%，其余业务基本稳定。'
    elif price_rise_all:
        price_trend_html = f'<strong>客单价：</strong>多个业务客单价提升，整体定价策略向好。'
    else:
        price_trend_html = '<strong>客单价：</strong>本期各业务客单价整体稳定，无明显波动。'

    # 转化率分析
    conv_up   = [b for b in BUSINESSES if p1[f'{b}转化率'] > p2[f'{b}转化率']]
    conv_down = [b for b in BUSINESSES if p1[f'{b}转化率'] < p2[f'{b}转化率']]
    # 剔除"以价换量"的业务（转化率提升但客单价大幅下降且毛利下降）
    fake_conv_up = [b for b in conv_up
                    if _chg(p1[f'{b}客单价'], p2[f'{b}客单价']) < -5
                    and _chg(p1[f'{b}毛利'], p2[f'{b}毛利']) <= 0]
    real_conv_up = [b for b in conv_up if b not in fake_conv_up]
    conv_html = ''
    if real_conv_up:
        conv_html += f'提升：{", ".join(real_conv_up)}；'
    if conv_down:
        conv_html += f'下降：{", ".join(conv_down)}；'
    if fake_conv_up:
        conv_html += f'{", ".join(fake_conv_up)}转化率提升但背景是客单价大幅下降，不列入正面案例。'

    # UV毛利价值分布
    uvval_sorted = sorted(BUSINESSES, key=lambda b: p1[f'{b}uv毛利价值'])
    uvval_dist   = '、'.join([f'{b}¥{p1[f"{b}uv毛利价值"]:.2f}' for b in uvval_sorted])

    # 集中度压力测试
    top1_biz = pos_biz[0][0] if pos_biz else None
    if top1_biz:
        top1_chg = pos_biz[0][1]
        others_profit = sum(v for _, v, _ in pos_biz[1:]) + sum(v for _, v, _ in neg_biz)
        pressure_text = (f'若{top1_biz}增速回落，其余业务合计净增仅'
                         f'{_fmt_wan2(others_profit)}万，整体增长将大幅收窄。')
    else:
        pressure_text = ''

    # 四象限HTML
    quad_html = f"""
  <h3>🧩 业务健康度矩阵（四象限）</h3>
  <p style="font-size:12px;color:var(--ts);margin-bottom:6px">
    坐标轴：<strong>纵轴 = 毛利增长率（成长动能）</strong>，
    <strong>横轴 = 毛利占比（战略重量）</strong>
    &nbsp;|&nbsp; 分界线：增长率中位数 <strong>{g_med:+.1f}%</strong>，
    毛利占比中位数 <strong>{s_med:.1f}%</strong>
  </p>
  <div class="matrix">
    <div class="matrix-cell" style="background:#E3F2FD;border-color:#64B5F6;">
      <div class="matrix-icon">🚀</div>
      <div class="matrix-title">新星业务（低占比 + 高增长）</div>
      <div style="font-size:11px;color:var(--ts);margin-bottom:10px">
        占比小但动能强 → 重点培育，评估能否扩规模进入明星象限
      </div>
      {_biz_list_html(quads['rising'])}
    </div>
    <div class="matrix-cell star">
      <div class="matrix-icon">🌟</div>
      <div class="matrix-title">明星业务（高占比 + 高增长）</div>
      <div style="font-size:11px;color:var(--ts);margin-bottom:10px">
        规模大且在增长 → 加大投入，复制增长密码
      </div>
      {_biz_list_html(quads['star'])}
    </div>
    <div class="matrix-cell" style="background:#FFEBEE;border-color:#EF9A9A;">
      <div class="matrix-icon">🐕</div>
      <div class="matrix-title">问题业务（低占比 + 低/负增长）</div>
      <div style="font-size:11px;color:var(--ts);margin-bottom:10px">
        占比小且在下滑 → 限期改善，若无起色评估收缩资源
      </div>
      {_biz_list_html(quads['problem'])}
    </div>
    <div class="matrix-cell cow">
      <div class="matrix-icon">🐄</div>
      <div class="matrix-title">现金牛业务（高占比 + 低/负增长）</div>
      <div style="font-size:11px;color:var(--ts);margin-bottom:10px">
        规模大但动能不足 → 守住规模，诊断增长乏力原因
      </div>
      {_biz_list_html(quads['cow'])}
    </div>
  </div>"""

    sec5 = f"""
<section id="sec5">
  <h2>第五部分：整体洞察与建议</h2>
  <h3>📊 整体洞察（4维度）</h3>
  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin-bottom:24px">
    <div style="background:var(--bg);border-radius:6px;padding:16px;border:1px solid var(--border)">
      <div style="font-weight:700;margin-bottom:8px">📊 毛利增长结构</div>
      <div style="font-size:13px;line-height:1.8">
        总毛利净增<strong>+{_fmt_wan2(net_chg)}万（{total_profit_chg:+.2f}%）</strong>，
        正增长{len(pos_biz)}个业务（贡献合计+{_fmt_wan2(pos_sum)}万），
        下滑{len(neg_biz)}个（拖累合计{_fmt_wan2(neg_sum)}万），其余为业务间归因差异。
        {"<br><br>增长高度集中：<strong>" + top1_biz + f"一项贡献+{_fmt_wan2(pos_biz[0][1])}万，占正增长总量{pos_biz[0][1]/pos_sum*100:.1f}%，占净增量{pos_biz[0][1]/net_chg*100:.1f}%</strong>。" + pressure_text if top1_biz and net_chg > 0 else ""}
      </div>
    </div>
    <div style="background:var(--bg);border-radius:6px;padding:16px;border:1px solid var(--border)">
      <div style="font-weight:700;margin-bottom:8px">🎯 流量变现效率</div>
      <div style="font-size:13px;line-height:1.8">
        访问毛利价值从¥{p2['访问毛利价值']:.2f}提升至¥{p1['访问毛利价值']:.2f}（<strong>{access_val_chg:+.2f}%</strong>）。
        UV毛利价值绝对值分布（低→高）：{uvval_dist}。
        整体效率{"改善" if access_val_chg > 0 else "下滑"}，
        但分化{"在加剧" if max(_chg(p1[f"{b}uv毛利价值"],p2[f"{b}uv毛利价值"]) for b in BUSINESSES) - min(_chg(p1[f"{b}uv毛利价值"],p2[f"{b}uv毛利价值"]) for b in BUSINESSES) > 30 else "较均衡"}。
      </div>
    </div>
    <div style="background:var(--bg);border-radius:6px;padding:16px;border:1px solid var(--border)">
      <div style="font-weight:700;margin-bottom:8px">📈 关键指标趋势</div>
      <div style="font-size:13px;line-height:1.8">
        <strong>流入率：</strong>从{p2['总业务uv流入率']:.2f}%{"提升" if inflow_chg_total>0 else "下降"}至{p1['总业务uv流入率']:.2f}%（{inflow_chg_total:+.2f}pp）。<br><br>
        {price_trend_html}<br><br>
        <strong>转化率：</strong>{conv_html}
      </div>
    </div>
    <div style="background:var(--bg);border-radius:6px;padding:16px;border:1px solid var(--border)">
      <div style="font-weight:700;margin-bottom:8px">🔄 增长模式分化</div>
      <div style="font-size:13px;line-height:1.8">
        {mode_html}
        <br><strong>穿透性判断：</strong>{penetration}
      </div>
    </div>
  </div>

  {quad_html}

</section>"""

    # ══════════════════════════════════════════════════════════════
    # 第六部分：战略建议（4卡片，含量化ROI）+ 行动计划（P0/P1/P2）
    # ══════════════════════════════════════════════════════════════

    # ── 找出关键业务 ──────────────────────────────────────────────
    biz_metrics = {}
    for biz in BUSINESSES:
        ba = results.get('business_analysis', {}).get(biz, {})
        m_biz = ba.get('_metrics', {})
        if not m_biz:  # 兼容旧版 analysis_core 未输出 _metrics 的情况
            m_biz = {
                'profit_chg_pct': _chg(p1[f'{biz}毛利'], p2[f'{biz}毛利']),
                'uv_chg_pct':    _chg(p1[f'{biz}uv'], p2[f'{biz}uv']),
                'conv_chg':      p1[f'{biz}转化率'] - p2[f'{biz}转化率'],
                'price_chg_pct': _chg(p1[f'{biz}客单价'], p2[f'{biz}客单价']),
                'uvval_chg_pct': _chg(p1[f'{biz}uv毛利价值'], p2[f'{biz}uv毛利价值']),
                'uvval1': p1[f'{biz}uv毛利价值'], 'uvval2': p2[f'{biz}uv毛利价值'],
                'price1': p1[f'{biz}客单价'],      'price2': p2[f'{biz}客单价'],
                'conv1':  p1[f'{biz}转化率'],       'conv2':  p2[f'{biz}转化率'],
                'uv1':    p1[f'{biz}uv'],            'uv2':    p2[f'{biz}uv'],
                'profit1':p1[f'{biz}毛利'],          'profit2':p2[f'{biz}毛利'],
            }
        biz_metrics[biz] = m_biz

    # 最大下滑业务
    worst_biz   = min(BUSINESSES, key=lambda b: _chg(p1[f'{b}毛利'], p2[f'{b}毛利']))
    # 第二大问题：反直觉 or 次差下滑
    sorted_by_chg = sorted(BUSINESSES, key=lambda b: _chg(p1[f'{b}毛利'], p2[f'{b}毛利']))
    second_problem = sorted_by_chg[1] if len(sorted_by_chg) > 1 else sorted_by_chg[0]
    # 最大增长引擎
    best_biz    = pos_biz[0][0] if pos_biz else BUSINESSES[0]
    # 第二大增长业务（用于复制模式）
    second_best = pos_biz[1][0] if len(pos_biz) > 1 else best_biz

    def _strategy_card(icon, title, body, roi_label):
        return (f'<div class="strategy-card">'
                f'<div class="strategy-icon">{icon}</div>'
                f'<div class="strategy-title">{title}</div>'
                f'<div class="strategy-text">{body}</div>'
                f'<div class="roi-tag">💰 ROI估算：{roi_label}</div>'
                f'</div>')

    # ── 卡片1：最大下滑业务止损 ────────────────────────────────────
    wm = biz_metrics[worst_biz]
    w_profit_chg = _chg(p1[f'{worst_biz}毛利'], p2[f'{worst_biz}毛利'])
    w_loss_wan   = (p1[f'{worst_biz}毛利'] - p2[f'{worst_biz}毛利']) / 10000  # 负数
    # ROI：恢复到去年水平可减少损失
    w_roi_wan    = abs(w_loss_wan)
    w_uv1        = p1[f'{worst_biz}uv']
    w_conv1      = p1[f'{worst_biz}转化率']
    w_price1     = p1[f'{worst_biz}客单价']
    w_price2     = p2[f'{worst_biz}客单价']
    w_margin1    = p1[f'{worst_biz}毛利率']

    if wm.get('uv_chg_pct', 0) > 5 and w_profit_chg < -5:
        w_root_cause = f'UV增长{wm["uv_chg_pct"]:.1f}%但毛利下滑，典型"来了不买"模式，根因在于新增流量质量偏低'
        w_path       = f'第一步：识别并砍掉低质量流量来源；第二步：优化落地页及产品呈现，提升目标用户匹配度'
    elif wm.get('price_chg_pct', 0) < -10:
        w_root_cause = f'客单价从¥{wm["price2"]:.2f}暴跌至¥{wm["price1"]:.2f}（{wm["price_chg_pct"]:.1f}%），需确认是主动降价、产品结构变化还是用户结构变化'
        w_path       = f'3天内完成数据层初步判断，7天内输出完整根因报告；根据根因制定差异化应对策略'
    else:
        w_root_cause = f'转化率与客单价双重下滑，变现能力全面退化'
        w_path       = f'3天内锁定最大拖累因子，7天内启动定向干预专项'

    card1_body = (f'<strong>目标：</strong>{worst_biz}毛利止血，将下滑幅度从{w_profit_chg:.1f}%收窄至-5%以内。<br><br>'
                  f'<strong>根因框架：</strong>{w_root_cause}。<br><br>'
                  f'<strong>干预路径：</strong>{w_path}。<br><br>'
                  f'<strong>防守目标：</strong>UV毛利价值恢复至¥{wm.get("uvval2", p2[f"{worst_biz}uv毛利价值"]):.2f}（{period2_name}水平），'
                  f'可减少损失约{w_roi_wan:.2f}万/周期。')
    card1_roi = f'恢复至{period2_name}水平可挽回约{w_roi_wan:.2f}万（UV×价值差额×毛利率）'

    # ── 卡片2：第二大问题/反直觉业务修复 ─────────────────────────
    sm = biz_metrics[second_problem]
    s_profit_chg = _chg(p1[f'{second_problem}毛利'], p2[f'{second_problem}毛利'])
    s_uvval_chg  = _chg(p1[f'{second_problem}uv毛利价值'], p2[f'{second_problem}uv毛利价值'])

    if sm.get('uv_chg_pct', 0) > 30 and s_uvval_chg < -15:
        s_disease  = f'流量虚增型——UV大涨{sm["uv_chg_pct"]:.1f}%但UV毛利价值跌{abs(s_uvval_chg):.1f}%，新增流量变现效率极低'
        s_fix_path = f'排查新增流量来源与用户画像；优化入口承接页；对低质渠道投放踩刹车'
    elif sm.get('price_chg_pct', 0) < -5 and sm.get('conv_chg', 0) > 0 and s_profit_chg < 0:
        s_disease  = f'疑似以价换量——客单价跌{abs(sm["price_chg_pct"]):.1f}%换来转化率提升，但毛利未改善'
        s_fix_path = f'分析促销政策与竞品定价；测试提价后转化率变化；寻找客单价与转化率的最优平衡点'
    elif s_profit_chg < -5:
        s_disease  = f'毛利下滑{abs(s_profit_chg):.1f}%，UV毛利价值¥{p1[f"{second_problem}uv毛利价值"]:.2f}持续恶化'
        s_fix_path = f'深入分析LMDI最大负向因子，制定针对性改善专项'
    else:
        s_disease  = f'增长动能不足，存在潜在恶化风险'
        s_fix_path = f'建立关键指标监控看板，提前预警恶化信号'

    # 修复ROI：目标UV毛利价值 × 当前UV规模
    s_uvval_target = p2[f'{second_problem}uv毛利价值']
    s_uv_cur       = p1[f'{second_problem}uv']
    s_roi_wan      = (s_uvval_target - p1[f'{second_problem}uv毛利价值']) * s_uv_cur / 10000

    card2_body = (f'<strong>核心病灶：</strong>{s_disease}。<br><br>'
                  f'<strong>修复路径：</strong>{s_fix_path}。<br><br>'
                  f'<strong>修复目标：</strong>UV毛利价值从¥{p1[f"{second_problem}uv毛利价值"]:.2f}'
                  f'恢复至¥{s_uvval_target:.2f}（{period2_name}水平）。')
    card2_roi = f'UV毛利价值提升至¥{s_uvval_target:.2f}，当前UV规模下增量约{abs(s_roi_wan):.2f}万'

    # ── 卡片3：最大增长引擎放大 ────────────────────────────────────
    bm  = biz_metrics[best_biz]
    b_profit_chg   = _chg(p1[f'{best_biz}毛利'], p2[f'{best_biz}毛利'])
    b_uvval1       = p1[f'{best_biz}uv毛利价值']
    b_uvval_median = statistics.median([p1[f'{b}uv毛利价值'] for b in BUSINESSES])
    # 放大ROI：UV×价值差额（目标=全场中位数）
    b_uv1       = p1[f'{best_biz}uv']
    b_val_target = max(b_uvval_median, b_uvval1 * 1.15)
    b_roi_wan    = (b_val_target - b_uvval1) * b_uv1 / 10000

    if b_profit_chg > 50:
        b_advantage = f'UV规模高速扩张（+{bm.get("uv_chg_pct",0):.1f}%），入口竞争力已验证'
        b_amplify   = (f'当前UV毛利价值¥{b_uvval1:.2f}低于全场中位数¥{b_uvval_median:.2f}，'
                       f'变现效率是最大提升空间。重点：①优化转化路径提升转化率；'
                       f'②测试高客单价套餐；③加大入口资源投入复制扩张优势')
    else:
        b_advantage = f'效率与规模双轮驱动，{bm.get("main_driver","指标")}为核心竞争力'
        b_amplify   = (f'在当前{b_advantage}的基础上，进一步扩大UV规模并维持UV毛利价值¥{b_uvval1:.2f}。'
                       f'若UV毛利价值能提升至¥{b_val_target:.2f}，可额外释放约{b_roi_wan:.2f}万/周期')

    card3_body = (f'<strong>当前优势：</strong>{best_biz} {b_advantage}，毛利增长{b_profit_chg:+.1f}%，'
                  f'贡献净增量{pos_biz[0][1]/net_chg*100:.1f}%。<br><br>'
                  f'<strong>放大路径：</strong>{b_amplify}。<br><br>'
                  f'<strong>投入方向：</strong>入口资源投放 + 变现链路优化 + 高客单价产品开发。')
    card3_roi = f'UV毛利价值目标¥{b_val_target:.2f}，增量约{b_roi_wan:.2f}万/周期'

    # ── 卡片4：成功模式复制 ────────────────────────────────────────
    # 找最佳效率驱动业务（量质齐升 or 效率驱动，且非best_biz）
    copy_candidates = [b for b in BUSINESSES if b != best_biz
                       and _growth_mode(b, p1, p2) in ('量质齐升', '效率驱动')
                       and _chg(p1[f'{b}毛利'], p2[f'{b}毛利']) > 5]
    copy_src = copy_candidates[0] if copy_candidates else second_best
    copy_mode = _growth_mode(copy_src, p1, p2)
    copy_uvval = p1[f'{copy_src}uv毛利价值']
    # 目标业务：UV毛利价值最低的正增长业务
    low_val_bizs = [b for b in BUSINESSES if _chg(p1[f'{b}毛利'], p2[f'{b}毛利']) > 0 and b != copy_src]
    copy_target  = min(low_val_bizs, key=lambda b: p1[f'{b}uv毛利价值']) if low_val_bizs else worst_biz
    copy_target_uvval = p1[f'{copy_target}uv毛利价值']
    copy_roi_wan      = (copy_uvval - copy_target_uvval) * p1[f'{copy_target}uv'] / 10000

    card4_body = (f'<strong>成功模式提炼：</strong>{copy_src}（{copy_mode}）UV毛利价值¥{copy_uvval:.2f}，'
                  f'通过{"转化率+毛利率双提升" if copy_mode=="效率驱动" else "量质同步扩张"}实现稳健增长。<br><br>'
                  f'<strong>复制方向：</strong>将{copy_src}的{"用户精准匹配方法论" if copy_mode=="效率驱动" else "流量扩张+变现协同路径"}'
                  f'移植至{copy_target}（UV毛利价值当前仅¥{copy_target_uvval:.2f}）。<br><br>'
                  f'<strong>试点计划：</strong>2周内完成方法论提炼，4周内在{copy_target}启动试点，'
                  f'验收标准：{copy_target} UV毛利价值提升10%以上。')
    card4_roi = f'{copy_target} UV毛利价值提升至¥{copy_uvval:.2f}，增量约{copy_roi_wan:.2f}万'

    strategy_html = f"""
  <div class="strategy-grid">
    {_strategy_card('🛑', f'止损：{worst_biz}止血行动', card1_body, card1_roi)}
    {_strategy_card('🔧', f'修复：{second_problem}变现效率重建', card2_body, card2_roi)}
    {_strategy_card('🚀', f'放大：{best_biz}增长引擎深化', card3_body, card3_roi)}
    {_strategy_card('📋', f'复制：{copy_src}成功模式移植', card4_body, card4_roi)}
  </div>"""

    # ── 行动计划表格（P0/P1/P2，5列）────────────────────────────
    def _action_row(priority, action, goal, owner, deadline):
        badge_cls = f'badge-{priority.lower()}'
        return (f'<tr><td><span class="{badge_cls}">{priority}</span></td>'
                f'<td style="text-align:left">{action}</td>'
                f'<td style="text-align:left;font-size:12px">{goal}</td>'
                f'<td>{owner}</td><td>{deadline}</td></tr>')

    action_rows = (
        # P0：最大下滑业务根因诊断（2阶段，P0数量≤3）
        _action_row('P0', f'{worst_biz} 数据层初步根因判断',
                    f'确认是流量质量、定价、还是产品问题；输出初步假设',
                    '业务负责人', '3天内') +
        _action_row('P0', f'{worst_biz} 完整根因报告',
                    f'输出3个根因假设的验证结论，确定优先级干预方案',
                    '业务负责人+数据分析', '7天内') +
        # P0：反直觉/第二问题业务专项排查（共3个P0，符合上限）
        _action_row('P0', f'{second_problem} 反直觉模式数据核查',
                    f'确认{s_disease[:25]}根本原因',
                    '运营负责人', '3天内') +
        # P1：止损干预
        _action_row('P1', f'{worst_biz} 干预执行',
                    f'基于根因报告启动定向干预，UV毛利价值恢复目标¥{wm.get("uvval2", 0):.2f}',
                    '业务负责人', '2-4周') +
        # P1：增长引擎变现提升
        _action_row('P1', f'{best_biz} 变现效率专项',
                    f'UV毛利价值提升目标¥{b_val_target:.2f}；优化转化路径+客单价测试',
                    '产品+运营', '2-4周') +
        # P1：成功模式复制试点
        _action_row('P1', f'{copy_src}→{copy_target} 方法论移植试点',
                    f'{copy_target} UV毛利价值提升10%以上（验收标准）',
                    '运营负责人', '4周') +
        # P2：监控体系
        _action_row('P2', '关键指标预警看板建立',
                    f'UV毛利价值、客单价、转化率设置阈值预警，异常48h内触发复盘',
                    '数据团队', '2周内') +
        _action_row('P2', '系统性降价倾向专项复盘',
                    f'4个业务客单价同向下滑，确认是否有系统性定价策略问题',
                    '商业化负责人', '2周内')
    )

    sec6 = f"""
<section id="sec6">
  <h2>第六部分：战略建议与行动计划</h2>
  <h3>🎯 战略建议（4卡片）</h3>
  {strategy_html}
  <h3 style="margin-top:28px">📋 行动计划</h3>
  <table>
    <thead><tr>
      <th style="width:60px">优先级</th><th>行动项</th>
      <th>核心目标与验收标准</th><th>负责人</th><th>截止时间</th>
    </tr></thead>
    <tbody>{action_rows}</tbody>
  </table>
</section>"""

    # ══════════════════════════════════════════════════════════════
    # JavaScript
    # ══════════════════════════════════════════════════════════════

    biz_list_js = json.dumps(BIZ_ORDER, ensure_ascii=False)
    js = f"""
<script>
const TREND = {trend_json};
const CHARTS = {{}};
const C_CURR='#E8724A', C_PREV='#5B7FA5';

function mkDs(label,data,color){{
  return {{label,data,borderColor:color,backgroundColor:color+'22',
          borderWidth:2,pointRadius:2,fill:false,tension:0.3}};
}}

function initCharts(biz){{
  const d=TREND[biz]['day'];
  const labels=d.labels1.length>=d.labels2.length?d.labels1:d.labels2;
  function mk(id,d1,d2){{
    const ctx=document.getElementById(id);
    if(!ctx)return null;
    return new Chart(ctx,{{type:'line',
      data:{{labels,datasets:[mkDs('{period2_name}',d2,C_PREV),mkDs('{period1_name}',d1,C_CURR)]}},
      options:{{responsive:true,maintainAspectRatio:true,
        plugins:{{legend:{{labels:{{boxWidth:10,font:{{size:11}}}}}}}},
        scales:{{x:{{ticks:{{font:{{size:10}},maxTicksLimit:12}}}},y:{{ticks:{{font:{{size:10}}}}}}}}
      }}
    }});
  }}
  CHARTS[biz]={{
    profit:mk(`chart-profit-${{biz}}`,d.profit1,d.profit2),
    uv:    mk(`chart-uv-${{biz}}`,d.uv1,d.uv2),
    uvval: mk(`chart-uvval-${{biz}}`,d.uvval1,d.uvval2),
    price: mk(`chart-price-${{biz}}`,d.price1,d.price2),
    inflow:mk(`chart-inflow-${{biz}}`,d.inflow1,d.inflow2),
  }};
}}

function switchGran(biz,gran,btn){{
  btn.closest('.gran-btns').querySelectorAll('.gran-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const d=TREND[biz][gran];
  const labels=d.labels1.length>=d.labels2.length?d.labels1:d.labels2;
  [['profit',d.profit1,d.profit2],['uv',d.uv1,d.uv2],
   ['uvval',d.uvval1,d.uvval2],['price',d.price1,d.price2],
   ['inflow',d.inflow1,d.inflow2]].forEach(([key,d1,d2])=>{{
    const c=CHARTS[biz][key]; if(!c)return;
    c.data.labels=labels;
    c.data.datasets[0].data=d2;
    c.data.datasets[1].data=d1;
    c.update();
  }});
}}

{biz_list_js}.forEach(b=>initCharts(b));

// ── TOC ──
function toggleToc(){{
  const s=document.getElementById('tocSidebar');
  const toggled=s.classList.toggle('collapsed');
  document.body.classList.toggle('toc-collapsed',toggled);
  localStorage.setItem('tocCollapsed',toggled);
}}
(function(){{
  if(localStorage.getItem('tocCollapsed')==='true'){{
    document.getElementById('tocSidebar').classList.add('collapsed');
    document.body.classList.add('toc-collapsed');
  }}
}})();
window.addEventListener('scroll',function(){{
  const items=document.querySelectorAll('section[id],.biz-card[id]');
  let cur='';
  items.forEach(function(el){{if(window.scrollY>=el.offsetTop-120)cur=el.id;}});
  document.querySelectorAll('.toc-nav a').forEach(function(a){{
    a.classList.toggle('active',a.getAttribute('href')==='#'+cur);
  }});
}});
</script>"""

    # ══════════════════════════════════════════════════════════════
    # TOC侧边栏 HTML
    # ══════════════════════════════════════════════════════════════

    biz_toc_links = '\n'.join(
        f'    <a href="#biz-{b}" class="toc-sub">· {b}</a>'
        for b in BIZ_ORDER
    )
    toc_html = f"""<div class="toc-sidebar" id="tocSidebar">
  <div class="toc-header">
    <span class="toc-title">📋 目录</span>
    <button class="toc-toggle" onclick="toggleToc()">◀</button>
  </div>
  <nav class="toc-nav">
    <a href="#sec1">一、核心摘要</a>
    <a href="#sec2">二、业务影响排序</a>
    <a href="#sec3">三、各业务详细分析</a>
{biz_toc_links}
    <a href="#sec4">四、反直觉模式汇总</a>
    <a href="#sec5">五、整体洞察与建议</a>
    <a href="#sec6">六、战略建议与行动计划</a>
  </nav>
</div>"""

    # ══════════════════════════════════════════════════════════════
    # 完整HTML拼装
    # ══════════════════════════════════════════════════════════════

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>增值业务流量分析报告_{period1_str}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>{CSS}</style>
</head>
<body>
{toc_html}
<div class="container">
<header>
  <h1>增值业务流量分析报告</h1>
  <div class="subtitle">
    分析周期：<span class="time-hl">{period1_str}</span>
    vs <span class="time-hl">{period2_str}</span>（各{DAYS}天）
  </div>
  <div class="meta">
    生成时间：{__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M')} |
    数据来源：增值业务流量转化明细表.xlsx |     版本：v6.1 |
  </div>
</header>

{sec1}
{sec2}
{sec3}
{sec4}
{sec5}
{sec6}

<footer>
  增值业务流量分析报告 · {period1_str} vs {period2_str} · 共{DAYS}天 · v6.1
</footer>
</div>
{js}
</body>
</html>"""

    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)

    return html


# ══════════════════════════════════════════════════════════════════
# 命令行入口
# ══════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import pickle

    # 默认在 增值业务/ 目录下运行
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pkl_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'analysis_results.pkl')
    data_path = os.path.join(base_dir, '增值业务流量转化明细表.xlsx')

    if not os.path.exists(pkl_path):
        print('analysis_results.pkl not found, running analysis...')
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from scripts.analysis_core import TrafficAnalysis
        analyzer = TrafficAnalysis(data_path)
        results = analyzer.full_analysis_by_date_range(
            period1_year=2026, period1_months=[1, 2, 3],
            period1_start_day=1, period1_end_day=25,
            period2_year=2025, period2_months=[1, 2, 3],
            period2_start_day=1, period2_end_day=25,
            period1_name='2026年', period2_name='2025年'
        )
        with open(pkl_path, 'wb') as f:
            pickle.dump(results, f)
    else:
        with open(pkl_path, 'rb') as f:
            results = pickle.load(f)

    params   = results['analysis_params']
    p1_info  = params['period1']
    out_name = os.path.join(base_dir, f"增值业务流量分析报告_{p1_info['year']}年.html")
    generate_html_report(results, output_path=out_name)
    print(f'报告已生成: {out_name}')
