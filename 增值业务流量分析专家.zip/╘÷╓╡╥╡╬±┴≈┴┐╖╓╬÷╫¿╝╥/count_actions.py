# -*- coding: utf-8 -*-
import re, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
path = r'C:\Users\64241\Desktop\新skill\新skill\增值业务\增值业务流量分析报告_2026年1月1日-3月25日.html'
with open(path, encoding='utf-8') as f:
    html = f.read()

p0 = len(re.findall('<span class="badge-p0">P0</span>', html))
p1 = len(re.findall('<span class="badge-p1">P1</span>', html))
p2 = len(re.findall('<span class="badge-p2">P2</span>', html))
print(f'实际行数: P0={p0}, P1={p1}, P2={p2}')
print(f'P0 <= 3: {"PASS" if p0 <= 3 else "FAIL"}')
