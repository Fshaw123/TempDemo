"""
增值业务流量转化数据分析核心模块
提供完整的数据处理、分析和报告生成功能

核心特性：
- 数据质量校验机制
- 量化归因分析（LMDI-I无残差分解）
- 反直觉模式检测（可调阈值）
- 同比/环比双维度分析
- 异常值自动检测
- HTML报告自动生成
- 自定义时间范围对比
- 趋势图可视化

版本：5.4.2
更新日期：2026-03-31
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union
import json
import sys
import os

# 添加validators和attribution到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 业务列表（固定顺序）
BUSINESSES = ['高速宝', '设备升级', '换车换牌', '注销新办', '延保', '增购', '会员']


def load_data(file_path: str) -> pd.DataFrame:
    """读取Excel数据并转换日期格式"""
    df = pd.read_excel(file_path)
    df['浏览日期'] = pd.to_datetime(df['浏览日期'])
    df['年'] = df['浏览日期'].dt.year
    df['月'] = df['浏览日期'].dt.month
    df['日'] = df['浏览日期'].dt.day
    df['年月'] = df['浏览日期'].dt.to_period('M')
    df['季度'] = df['浏览日期'].dt.quarter
    df['年月日'] = df['浏览日期'].dt.date
    return df


def calc_derived_metrics(summary: pd.DataFrame) -> pd.DataFrame:
    """计算衍生指标（带除零保护）"""
    result = summary.copy()
    
    # 总体指标（带除零保护）
    result['总业务uv流入率'] = np.where(
        result['访问人数'] > 0,
        result['总业务uv'] / result['访问人数'] * 100,
        0
    )
    result['访问毛利价值'] = np.where(
        result['访问人数'] > 0,
        result['总毛利'] / result['访问人数'],
        0
    )
    result['总业务uv毛利价值'] = np.where(
        result['总业务uv'] > 0,
        result['总毛利'] / result['总业务uv'],
        0
    )
    
    # 各业务指标（带除零保护）
    for biz in BUSINESSES:
        result[f'{biz}流入率'] = np.where(
            result['访问人数'] > 0,
            result[f'{biz}uv'] / result['访问人数'] * 100,
            0
        )
        result[f'{biz}转化率'] = np.where(
            result[f'{biz}uv'] > 0,
            result[f'{biz}订单数'] / result[f'{biz}uv'] * 100,
            0
        )
        result[f'{biz}客单价'] = np.where(
            result[f'{biz}订单数'] > 0,
            result[f'{biz}支付金额'] / result[f'{biz}订单数'],
            0
        )
        result[f'{biz}uv毛利价值'] = np.where(
            result[f'{biz}uv'] > 0,
            result[f'{biz}毛利'] / result[f'{biz}uv'],
            0
        )
        result[f'{biz}毛利占比'] = np.where(
            result['总毛利'] > 0,
            result[f'{biz}毛利'] / result['总毛利'] * 100,
            0
        )
        # 新增：毛利率
        result[f'{biz}毛利率'] = np.where(
            result[f'{biz}支付金额'] > 0,
            result[f'{biz}毛利'] / result[f'{biz}支付金额'] * 100,
            0
        )
    
    return result


def period_summary(df: pd.DataFrame, year: int, months: List[int], 
                   start_day: Optional[int] = None, end_day: Optional[int] = None) -> Dict:
    """
    按指定年份、月份和日期范围汇总数据
    
    Args:
        year: 年份
        months: 月份列表
        start_day: 开始日期（可选，如1表示从1号开始）
        end_day: 结束日期（可选，如24表示到24号结束）
    """
    # 构建日期范围筛选条件
    if len(months) == 1:
        # 单月份：直接使用年月日筛选
        mask = (df['年'] == year) & (df['月'] == months[0])
        if start_day is not None:
            mask = mask & (df['日'] >= start_day)
        if end_day is not None:
            mask = mask & (df['日'] <= end_day)
    else:
        # 多月份：需要处理跨月日期范围
        # 例如：1月15日 到 2月20日
        masks = []
        sorted_months = sorted(months)
        
        for i, month in enumerate(sorted_months):
            month_mask = (df['年'] == year) & (df['月'] == month)
            
            if i == 0 and start_day is not None:
                # 第一个月：从start_day开始
                month_mask = month_mask & (df['日'] >= start_day)
            elif i == len(sorted_months) - 1 and end_day is not None:
                # 最后一个月：到end_day结束
                month_mask = month_mask & (df['日'] <= end_day)
            # 中间月份：不限制日期
            
            masks.append(month_mask)
        
        mask = masks[0]
        for m in masks[1:]:
            mask = mask | m
    
    df_period = df[mask]
    
    sum_cols = ['总毛利', '访问人数', '总业务uv', '总支付金额']
    for biz in BUSINESSES:
        sum_cols.extend([f'{biz}毛利', f'{biz}uv', f'{biz}支付金额', f'{biz}订单数'])
    
    result = df_period[sum_cols].sum().to_dict()
    result['天数'] = len(df_period)
    
    # 生成时间段描述
    if start_day is not None and end_day is not None:
        result['时间段'] = f"{year}年{months[0]}月{start_day}日-{months[-1]}月{end_day}日"
    elif start_day is not None:
        result['时间段'] = f"{year}年{months[0]}月{start_day}日起"
    elif end_day is not None:
        result['时间段'] = f"{year}年{months[0]}月1日-{end_day}日"
    else:
        result['时间段'] = f"{year}年{'-'.join(map(str, months))}月"
    
    # 计算衍生指标
    result_df = calc_derived_metrics(pd.DataFrame([result]))
    result = result_df.iloc[0].to_dict()
    
    return result


def yoy_analysis(df: pd.DataFrame, current_year: int, months: List[int], 
                 previous_year: Optional[int] = None) -> pd.DataFrame:
    """同比分析：当前期间 vs 去年同期"""
    if previous_year is None:
        previous_year = current_year - 1
    
    current = period_summary(df, current_year, months)
    previous = period_summary(df, previous_year, months)
    
    result = []
    for key in current:
        if key in ['时间段', '天数']:
            continue
        
        curr_val = current[key]
        prev_val = previous[key]
        change = curr_val - prev_val
        change_pct = (change / prev_val * 100) if prev_val != 0 else np.inf
        
        result.append({
            '指标': key,
            '当期': curr_val,
            '同期': prev_val,
            '变化值': change,
            '变化率%': change_pct
        })
    
    return pd.DataFrame(result)


def mom_analysis(df: pd.DataFrame, current_year: int, current_months: List[int],
                 period_type: str = 'month') -> pd.DataFrame:
    """
    环比分析：当前期间 vs 上一期间
    
    Args:
        period_type: 'month' 月环比, 'quarter' 季环比
    """
    # 计算上一期间
    if period_type == 'month':
        # 上一个月
        first_month = min(current_months)
        if first_month == 1:
            prev_year = current_year - 1
            prev_months = [12]
        else:
            prev_year = current_year
            prev_months = [first_month - 1]
    elif period_type == 'quarter':
        # 上一个季度
        first_month = min(current_months)
        quarter = (first_month - 1) // 3 + 1
        if quarter == 1:
            prev_year = current_year - 1
            prev_months = [10, 11, 12]
        else:
            prev_year = current_year
            prev_months = list(range((quarter - 2) * 3 + 1, (quarter - 1) * 3 + 1))
    else:
        raise ValueError(f"不支持的period_type: {period_type}")
    
    current = period_summary(df, current_year, current_months)
    previous = period_summary(df, prev_year, prev_months)
    
    result = []
    for key in current:
        if key in ['时间段', '天数']:
            continue
        
        curr_val = current[key]
        prev_val = previous[key]
        change = curr_val - prev_val
        change_pct = (change / prev_val * 100) if prev_val != 0 else np.inf
        
        result.append({
            '指标': key,
            '当期': curr_val,
            '上期': prev_val,
            '变化值': change,
            '变化率%': change_pct
        })
    
    return pd.DataFrame(result)


def business_impact_ranking(df: pd.DataFrame, current_year: int, months: List[int],
                            previous_year: Optional[int] = None) -> pd.DataFrame:
    """计算各业务对总毛利的影响并排序"""
    if previous_year is None:
        previous_year = current_year - 1
    
    current = period_summary(df, current_year, months)
    previous = period_summary(df, previous_year, months)
    
    impact = []
    for biz in BUSINESSES:
        curr_profit = current[f'{biz}毛利']
        prev_profit = previous[f'{biz}毛利']
        change = curr_profit - prev_profit
        change_pct = (change / prev_profit * 100) if prev_profit != 0 else np.inf
        
        impact.append({
            '业务': biz,
            '当期毛利': curr_profit,
            '同期毛利': prev_profit,
            '绝对变化': change,
            '变化率%': change_pct,
            '当期毛利占比%': current[f'{biz}毛利占比']
        })
    
    result = pd.DataFrame(impact)
    result = result.sort_values('绝对变化', ascending=False).reset_index(drop=True)
    result.index = result.index + 1
    result.index.name = '排名'
    
    return result


def detect_outliers(df: pd.DataFrame, column: str, threshold: float = 3.0) -> pd.DataFrame:
    """
    使用Z-score检测异常值
    
    Args:
        threshold: Z-score阈值，默认3（99.7%置信区间）
    """
    mean = df[column].mean()
    std = df[column].std()
    
    if std == 0:
        return pd.DataFrame()
    
    z_scores = np.abs((df[column] - mean) / std)
    outliers = df[z_scores > threshold].copy()
    outliers['Z-score'] = z_scores[z_scores > threshold]
    
    return outliers


def validate_data(df: pd.DataFrame) -> Dict:
    """数据质量检查（增强版）"""
    issues = []
    warnings = []
    
    # 0. 数据类型校验
    numeric_columns = ['总毛利', '访问人数', '总业务uv', '总支付金额']
    for biz in BUSINESSES:
        numeric_columns.extend([f'{biz}毛利', f'{biz}uv', f'{biz}支付金额', f'{biz}订单数'])
    
    for col in numeric_columns:
        if col in df.columns:
            # 检查是否为数值类型
            if not pd.api.types.is_numeric_dtype(df[col]):
                issues.append(f"{col}列数据类型错误，期望数值类型，实际为{df[col].dtype}")
            else:
                # 检查是否包含负数（除特定列外）
                if col not in []:  # 可以在这里添加允许负数的列
                    negative_count = (df[col] < 0).sum()
                    if negative_count > 0:
                        issues.append(f"{col}列包含{negative_count}个负值，请检查数据")
                
                # 检查是否包含无穷大或NaN
                inf_count = np.isinf(df[col]).sum()
                if inf_count > 0:
                    issues.append(f"{col}列包含{inf_count}个无穷大值")
    
    # 检查日期列
    if '浏览日期' in df.columns:
        if not pd.api.types.is_datetime64_any_dtype(df['浏览日期']):
            try:
                pd.to_datetime(df['浏览日期'])
            except:
                issues.append("浏览日期列格式错误，无法转换为日期类型")
    
    # 1. 基础一致性检查
    business_profit_sum = sum(df[f'{biz}毛利'] for biz in BUSINESSES)
    total_profit_diff = abs(df['总毛利'] - business_profit_sum).max()
    if total_profit_diff > 1:
        issues.append(f"总毛利与各业务毛利之和不一致，最大差异: {total_profit_diff:.2f}元")
    
    business_payment_sum = sum(df[f'{biz}支付金额'] for biz in BUSINESSES)
    total_payment_diff = abs(df['总支付金额'] - business_payment_sum).max()
    if total_payment_diff > 1:
        issues.append(f"总支付金额与各业务支付金额之和不一致，最大差异: {total_payment_diff:.2f}元")
    
    # 2. 合理性检查
    for biz in BUSINESSES:
        inflow_rate = df[f'{biz}uv'] / df['访问人数'] * 100
        if (inflow_rate > 100).any():
            issues.append(f"{biz}流入率超过100%")
        
        conversion_rate = df[f'{biz}订单数'] / df[f'{biz}uv'] * 100
        if (conversion_rate > 100).any():
            issues.append(f"{biz}转化率超过100%")
    
    # 3. 异常值检测
    for biz in BUSINESSES:
        # 检测毛利异常值
        profit_outliers = detect_outliers(df, f'{biz}毛利', threshold=3)
        if len(profit_outliers) > 0:
            warnings.append(f"{biz}毛利发现{len(profit_outliers)}个异常值（|Z-score|>3）")
        
        # 检测转化率异常值（需要计算）
        conversion_rate_col = f'{biz}转化率'
        if conversion_rate_col in df.columns:
            conversion_outliers = detect_outliers(df, conversion_rate_col, threshold=3)
            if len(conversion_outliers) > 0:
                warnings.append(f"{biz}转化率发现{len(conversion_outliers)}个异常值")
    
    # 4. 缺失数据检查
    total_rows = len(df)
    for col in df.columns:
        missing_count = df[col].isna().sum()
        if missing_count > 0:
            missing_pct = missing_count / total_rows * 100
            if missing_pct > 5:
                issues.append(f"{col}缺失率{missing_pct:.1f}%（>5%），建议检查数据源")
            else:
                warnings.append(f"{col}缺失率{missing_pct:.1f}%")
    
    return {
        'valid': len(issues) == 0,
        'issues': issues,
        'warnings': warnings,
        'check_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }


class TrafficAnalysis:
    """流量分析类（集成所有功能）"""
    
    def __init__(self, file_path: str):
        """初始化并加载数据"""
        self.df = load_data(file_path)
        self.validation_result = validate_data(self.df)
        self.analysis_history = []
        
        if not self.validation_result['valid']:
            print("数据质量问题：")
            for issue in self.validation_result['issues']:
                print(f"  - {issue}")
        
        if self.validation_result['warnings']:
            print("\n数据警告：")
            for warning in self.validation_result['warnings']:
                print(f"  - {warning}")
    
    def generate_comparison_table(self, current_year: int, months: List[int], 
                                   biz_name: str, previous_year: Optional[int] = None) -> pd.DataFrame:
        """生成指标对比表"""
        if previous_year is None:
            previous_year = current_year - 1
        
        current = period_summary(self.df, current_year, months)
        previous = period_summary(self.df, previous_year, months)
        
        metrics = [
            ('UV', f'{biz_name}uv', '人'),
            ('流入率', f'{biz_name}流入率', '%'),
            ('转化率', f'{biz_name}转化率', '%'),
            ('客单价', f'{biz_name}客单价', '元'),
            ('毛利', f'{biz_name}毛利', '元'),
            ('UV毛利价值', f'{biz_name}uv毛利价值', '元'),
            ('毛利率', f'{biz_name}毛利率', '%'),
        ]
        
        table = []
        for metric_name, key, unit in metrics:
            curr_val = current[key]
            prev_val = previous[key]
            
            if '率' in metric_name and metric_name != 'UV毛利价值':
                change = curr_val - prev_val
                change_str = f"{change:+.2f}pp"
                direction = "上升" if change > 0 else "下降" if change < 0 else "持平"
                curr_str = f"{curr_val:.2f}%"
                prev_str = f"{prev_val:.2f}%"
            elif metric_name in ['UV', '毛利']:
                # UV和毛利使用万格式
                change_pct = (curr_val - prev_val) / prev_val * 100 if prev_val != 0 else 0
                change_str = f"{change_pct:+.2f}%"
                direction = "增长" if change_pct > 0 else "下降" if change_pct < 0 else "持平"
                curr_str = f"{curr_val/10000:.1f}万"
                prev_str = f"{prev_val/10000:.1f}万"
            else:
                change_pct = (curr_val - prev_val) / prev_val * 100 if prev_val != 0 else 0
                change_str = f"{change_pct:+.2f}%"
                direction = "增长" if change_pct > 0 else "下降" if change_pct < 0 else "持平"
                curr_str = f"{curr_val:,.2f}"
                prev_str = f"{prev_val:,.2f}"
            
            # 标记异常模式
            flag = ""
            if metric_name == '转化率' and direction == "下降":
                flag = "注意"
            elif metric_name == 'UV':
                change_pct = (curr_val - prev_val) / prev_val * 100 if prev_val != 0 else 0
                if abs(change_pct) > 100:
                    flag = "大幅波动"
            elif metric_name == '毛利率' and direction == "下降":
                flag = "盈利下降"
            
            table.append({
                '指标': metric_name,
                f'{previous_year}年': prev_str,
                f'{current_year}年': curr_str,
                '变化': change_str,
                '方向': direction,
                '标记': flag
            })
        
        return pd.DataFrame(table)
    
    def decompose_profit_change(self, current_year: int, months: List[int], 
                                 biz_name: str, previous_year: Optional[int] = None) -> Dict:
        """
        毛利变化量化归因分解（LMDI-I无残差分解）
        
        使用Ang和Choi提出的LMDI-I方法，确保无残差
        """
        if previous_year is None:
            previous_year = current_year - 1
        
        current = period_summary(self.df, current_year, months)
        previous = period_summary(self.df, previous_year, months)
        
        # 获取基础数据
        curr_uv = current[f'{biz_name}uv']
        prev_uv = previous[f'{biz_name}uv']
        curr_conversion = current[f'{biz_name}转化率'] / 100
        prev_conversion = previous[f'{biz_name}转化率'] / 100
        curr_price = current[f'{biz_name}客单价']
        prev_price = previous[f'{biz_name}客单价']
        curr_profit = current[f'{biz_name}毛利']
        prev_profit = previous[f'{biz_name}毛利']
        
        # 计算平均毛利率
        curr_orders = curr_uv * curr_conversion
        prev_orders = prev_uv * prev_conversion
        curr_margin_rate = curr_profit / (curr_orders * curr_price) if curr_orders > 0 else 0
        prev_margin_rate = prev_profit / (prev_orders * prev_price) if prev_orders > 0 else 0
        
        # LMDI-I分解（对数平均迪氏指数分解法）
        def log_mean(a, b):
            """计算对数平均权重"""
            if a == b:
                return a
            if a == 0 or b == 0:
                return (a + b) / 2
            return (a - b) / (np.log(a) - np.log(b))
        
        # 计算权重（对数平均）
        weight = log_mean(curr_profit, prev_profit)
        
        # 各因素贡献（LMDI-I公式）
        contributions = {}
        
        # UV贡献
        if curr_uv > 0 and prev_uv > 0:
            contributions['UV变化贡献'] = weight * np.log(curr_uv / prev_uv)
        else:
            contributions['UV变化贡献'] = curr_profit - prev_profit if prev_uv == 0 else 0
        
        # 转化率贡献
        if curr_conversion > 0 and prev_conversion > 0:
            contributions['转化率变化贡献'] = weight * np.log(curr_conversion / prev_conversion)
        else:
            contributions['转化率变化贡献'] = 0
        
        # 客单价贡献
        if curr_price > 0 and prev_price > 0:
            contributions['客单价变化贡献'] = weight * np.log(curr_price / prev_price)
        else:
            contributions['客单价变化贡献'] = 0
        
        # 毛利率贡献
        if curr_margin_rate > 0 and prev_margin_rate > 0:
            contributions['毛利率变化贡献'] = weight * np.log(curr_margin_rate / prev_margin_rate)
        else:
            contributions['毛利率变化贡献'] = 0
        
        # 总变化
        total_change = curr_profit - prev_profit
        
        # 验证无残差
        sum_contributions = sum(contributions.values())
        residual = total_change - sum_contributions
        
        # 如果残差过大，进行比例调整
        if abs(residual) > 0.01 and abs(total_change) > 0.01:
            adjustment_factor = total_change / sum_contributions
            for key in contributions:
                contributions[key] *= adjustment_factor
            sum_contributions = sum(contributions.values())
            residual = total_change - sum_contributions
        
        return {
            '业务': biz_name,
            '当期毛利': curr_profit,
            '同期毛利': prev_profit,
            '总变化': total_change,
            **contributions,
            '残差': residual,
            '验证总和': sum_contributions,
            '基础数据': {
                'UV': {'当期': curr_uv, '同期': prev_uv, '变化率': (curr_uv/prev_uv-1)*100 if prev_uv > 0 else 0},
                '转化率': {'当期': curr_conversion*100, '同期': prev_conversion*100, '变化pp': (curr_conversion-prev_conversion)*100},
                '客单价': {'当期': curr_price, '同期': prev_price, '变化率': (curr_price/prev_price-1)*100 if prev_price > 0 else 0},
                '毛利率': {'当期': curr_margin_rate*100, '同期': prev_margin_rate*100, '变化pp': (curr_margin_rate-prev_margin_rate)*100},
            }
        }
    
    def detect_counter_intuitive_patterns(self, current_year: int, months: List[int],
                                          previous_year: Optional[int] = None,
                                          uv_threshold: float = 2.0,
                                          conversion_threshold: float = -0.3) -> List[Dict]:
        """
        检测反直觉模式（支持自定义阈值）
        
        Args:
            uv_threshold: UV暴涨阈值（倍数），默认2.0（增长200%）
            conversion_threshold: 转化率下降阈值（pp），默认-0.3
        """
        if previous_year is None:
            previous_year = current_year - 1
        
        current = period_summary(self.df, current_year, months)
        previous = period_summary(self.df, previous_year, months)
        
        warnings = []
        
        for biz in BUSINESSES:
            uv_change = (current[f'{biz}uv'] - previous[f'{biz}uv']) / previous[f'{biz}uv'] if previous[f'{biz}uv'] > 0 else 0
            conversion_change = current[f'{biz}转化率'] - previous[f'{biz}转化率']
            profit_change = (current[f'{biz}毛利'] - previous[f'{biz}毛利']) / previous[f'{biz}毛利'] if previous[f'{biz}毛利'] > 0 else 0
            price_change = (current[f'{biz}客单价'] - previous[f'{biz}客单价']) / previous[f'{biz}客单价'] if previous[f'{biz}客单价'] > 0 else 0
            
            # 模式1：UV暴涨但转化率下降（使用自定义阈值）
            if uv_change > uv_threshold and conversion_change < conversion_threshold:
                severity = '高' if uv_change > 3.0 else '中'
                warnings.append({
                    '业务': biz,
                    '模式': 'UV暴涨但转化率下降',
                    '严重程度': severity,
                    '说明': f'UV增长{uv_change*100:.0f}%，但转化率下降{abs(conversion_change):.2f}pp',
                    '根因': '流量增长伴随质量稀释，可能原因：1)新流量渠道质量较低 2)页面体验下降 3)促销活动吸引非目标用户',
                    '建议': '1)分析新流量来源质量 2)优化落地页体验 3)精准定位目标用户 4)不要简单认为"全面向好"',
                    '数据': {
                        'UV变化': f"{uv_change*100:+.2f}%",
                        '转化率变化': f"{conversion_change:+.2f}pp",
                        '毛利变化': f"{profit_change*100:+.2f}%"
                    }
                })
            
            # 模式2：毛利增长但UV下降
            if profit_change > 0.2 and uv_change < -0.1:
                warnings.append({
                    '业务': biz,
                    '模式': '毛利增长但UV下降',
                    '严重程度': '中',
                    '说明': f'毛利增长{profit_change*100:.0f}%，但UV下降{abs(uv_change*100):.0f}%',
                    '根因': '依赖效率提升（转化率、客单价）而非规模扩张',
                    '建议': '关注可持续性，UV下降可能预示长期风险。建议分析用户留存、复购率等指标。',
                    '数据': {
                        'UV变化': f"{uv_change*100:+.2f}%",
                        '毛利变化': f"{profit_change*100:+.2f}%"
                    }
                })
            
            # 模式3：转化率提升但客单价大幅下降
            if conversion_change > 0.5 and price_change < -0.2:
                warnings.append({
                    '业务': biz,
                    '模式': '转化率提升但客单价大幅下降',
                    '严重程度': '中',
                    '说明': f'转化率提升{conversion_change:.2f}pp，但客单价下降{abs(price_change*100):.0f}%',
                    '根因': '可能采取了降价促销策略或推低客单价产品',
                    '建议': '评估降价策略的长期影响，关注利润率变化。',
                    '数据': {
                        '转化率变化': f"{conversion_change:+.2f}pp",
                        '客单价变化': f"{price_change*100:+.2f}%"
                    }
                })
        
        return warnings
    
    def analyze_cross_effects(self, current_year: int, months: List[int],
                              previous_year: Optional[int] = None) -> Dict:
        """
        分析UV-转化率交叉效应
        
        检测UV增长和转化率变化是否存在相关性
        """
        if previous_year is None:
            previous_year = current_year - 1
        
        current = period_summary(self.df, current_year, months)
        previous = period_summary(self.df, previous_year, months)
        
        cross_effects = {}
        
        for biz in BUSINESSES:
            uv_change = (current[f'{biz}uv'] - previous[f'{biz}uv']) / previous[f'{biz}uv'] if previous[f'{biz}uv'] > 0 else 0
            conversion_change = current[f'{biz}转化率'] - previous[f'{biz}转化率']
            
            # 判断交叉效应类型
            if uv_change > 0.5 and conversion_change < -0.2:
                effect_type = '负相关'
                description = 'UV大幅增长伴随转化率显著下降，存在明显的流量质量稀释效应'
            elif uv_change > 0.5 and conversion_change > 0:
                effect_type = '正相关'
                description = 'UV增长同时转化率提升，流量质量与规模同步改善'
            elif abs(uv_change) < 0.1 and abs(conversion_change) > 0.3:
                effect_type = '纯效率驱动'
                description = 'UV稳定，转化率大幅变化，增长完全由效率提升驱动'
            else:
                effect_type = '弱相关'
                description = 'UV和转化率变化无明显相关性'
            
            cross_effects[biz] = {
                '效应类型': effect_type,
                '描述': description,
                'UV变化': uv_change,
                '转化率变化': conversion_change,
                '相关性强度': abs(uv_change * conversion_change)
            }
        
        # 7. 业务分析总结 - 基于实际数据的准确评价（修正版）
        print(f"\n[7/7] 生成业务分析总结（灵活对比版）...")
        business_analysis = {}
        for biz in BUSINESSES:
            p1_profit = period1_summary[f'{biz}毛利']
            p2_profit = period2_summary[f'{biz}毛利']
            profit_change = p1_profit - p2_profit
            profit_change_pct = (profit_change / p2_profit * 100) if p2_profit > 0 else 0
            
            uv_change_pct = ((period1_summary[f'{biz}uv'] - period2_summary[f'{biz}uv']) / period2_summary[f'{biz}uv'] * 100) if period2_summary[f'{biz}uv'] > 0 else 0
            inflow_change = period1_summary[f'{biz}流入率'] - period2_summary[f'{biz}流入率']
            conversion_change = period1_summary[f'{biz}转化率'] - period2_summary[f'{biz}转化率']
            price_change_pct = ((period1_summary[f'{biz}客单价'] - period2_summary[f'{biz}客单价']) / period2_summary[f'{biz}客单价'] * 100) if period2_summary[f'{biz}客单价'] > 0 else 0
            value_change_pct = ((period1_summary[f'{biz}uv毛利价值'] - period2_summary[f'{biz}uv毛利价值']) / period2_summary[f'{biz}uv毛利价值'] * 100) if period2_summary[f'{biz}uv毛利价值'] > 0 else 0
            
            # 判断趋势
            if profit_change_pct > 30:
                trend = '爆发式增长'
            elif profit_change_pct > 10:
                trend = '稳健增长'
            elif profit_change_pct > 0:
                trend = '增长'
            elif profit_change_pct > -5:
                trend = '轻微下降'
            else:
                trend = '大幅下降'
            
            # 构建驱动因素 - 基于实际数据（使用严格阈值）
            drivers = []
            if uv_change_pct > 5:
                drivers.append(f"流量规模扩大：UV从{period2_summary[f'{biz}uv']/10000:.1f}万增长至{period1_summary[f'{biz}uv']/10000:.1f}万（+{uv_change_pct:.2f}%）")
            if inflow_change > 0.2:
                drivers.append(f"入口吸引力增强：流入率从{period2_summary[f'{biz}流入率']:.2f}%提升至{period1_summary[f'{biz}流入率']:.2f}%（+{inflow_change:.2f}pp）")
            if conversion_change > 0.2:
                drivers.append(f"转化效率提升：转化率从{period2_summary[f'{biz}转化率']:.2f}%提升至{period1_summary[f'{biz}转化率']:.2f}%（+{conversion_change:.2f}pp）")
            if price_change_pct > 3:
                drivers.append(f"客单价提升：从¥{period2_summary[f'{biz}客单价']:.2f}提升至¥{period1_summary[f'{biz}客单价']:.2f}（+{price_change_pct:.2f}%）")
            if value_change_pct > 5:
                drivers.append(f"UV价值提升：从¥{period2_summary[f'{biz}uv毛利价值']:.2f}提升至¥{period1_summary[f'{biz}uv毛利价值']:.2f}（+{value_change_pct:.2f}%）")
            
            # 构建挑战 - 基于实际数据（使用严格阈值）
            challenges = []
            if uv_change_pct < -5:
                challenges.append(f"流量规模收缩：UV从{period2_summary[f'{biz}uv']/10000:.1f}万下降至{period1_summary[f'{biz}uv']/10000:.1f}万（{uv_change_pct:.2f}%）")
            if inflow_change < -0.2:
                challenges.append(f"入口吸引力减弱：流入率从{period2_summary[f'{biz}流入率']:.2f}%下降至{period1_summary[f'{biz}流入率']:.2f}%（{inflow_change:.2f}pp）")
            if conversion_change < -0.2:
                challenges.append(f"转化效率下降：转化率从{period2_summary[f'{biz}转化率']:.2f}%下降至{period1_summary[f'{biz}转化率']:.2f}%（{conversion_change:.2f}pp）")
            if price_change_pct < -3:
                challenges.append(f"客单价下滑：从¥{period2_summary[f'{biz}客单价']:.2f}下降至¥{period1_summary[f'{biz}客单价']:.2f}（{price_change_pct:.2f}%）")
            if value_change_pct < -5:
                challenges.append(f"UV价值下降：从¥{period2_summary[f'{biz}uv毛利价值']:.2f}下降至¥{period1_summary[f'{biz}uv毛利价值']:.2f}（{value_change_pct:.2f}%）")
            
            # 生成准确的综合评价 - 基于实际数据逻辑（修正版）
            if profit_change_pct > 0:
                # 增长情况
                if uv_change_pct > 5 and conversion_change > 0:
                    evaluation = f'{biz}业务实现全面增长，UV增长{uv_change_pct:.2f}%且转化率提升{conversion_change:.2f}pp，"流量+效率"双轮驱动带来{profit_change_pct:.2f}%的毛利增长。'
                elif uv_change_pct > 5 and conversion_change <= 0:
                    evaluation = f'{biz}业务UV增长{uv_change_pct:.2f}%带动毛利增长{profit_change_pct:.2f}%，但转化率下降{abs(conversion_change):.2f}pp显示流量质量有稀释，需关注转化效率优化。'
                elif abs(uv_change_pct) < 5 and conversion_change > 0:
                    evaluation = f'{biz}业务在UV规模基本持平的情况下，依靠转化率提升{conversion_change:.2f}pp实现毛利增长{profit_change_pct:.2f}%，增长由效率驱动。'
                elif uv_change_pct < -5 and conversion_change > 0:
                    evaluation = f'{biz}业务UV下降{abs(uv_change_pct):.2f}%，但依靠转化率提升{conversion_change:.2f}pp和客单价提升{price_change_pct:.2f}%实现毛利增长{profit_change_pct:.2f}%，增长质量较高但需关注流量可持续性。'
                elif price_change_pct > 3 and value_change_pct > 0:
                    evaluation = f'{biz}业务UV规模{"基本持平" if abs(uv_change_pct) < 5 else f"变化{uv_change_pct:.2f}%"}、转化率{"持平" if abs(conversion_change) < 0.2 else f"变化{conversion_change:.2f}pp"}，主要依靠客单价提升{price_change_pct:.2f}%和UV价值提升{value_change_pct:.2f}%实现毛利增长{profit_change_pct:.2f}%。'
                else:
                    evaluation = f'{biz}业务实现{profit_change_pct:.2f}%的毛利增长。'
            else:
                # 下降情况
                decline_reasons = []
                if uv_change_pct < -5:
                    decline_reasons.append(f"UV下降{abs(uv_change_pct):.2f}%")
                if conversion_change < -0.2:
                    decline_reasons.append(f"转化率下降{abs(conversion_change):.2f}pp")
                if price_change_pct < -3:
                    decline_reasons.append(f"客单价下降{abs(price_change_pct):.2f}%")
                if value_change_pct < -5:
                    decline_reasons.append(f"UV价值下降{abs(value_change_pct):.2f}%")
                
                if decline_reasons:
                    evaluation = f'{biz}业务毛利下降{abs(profit_change_pct):.2f}%，主要受{"、".join(decline_reasons)}影响，需针对性优化。'
                else:
                    evaluation = f'{biz}业务毛利下降{abs(profit_change_pct):.2f}%，需深入分析具体原因。'
            
            business_analysis[biz] = {
                '趋势': trend,
                '驱动因素': drivers,
                '挑战': challenges,
                '综合评价': evaluation
            }
        
        print("\n" + "=" * 80)
        print("【灵活时间对比分析】执行完成")
        print("=" * 80)
        
        return {
            'current_summary': period1_summary,
            'previous_summary': period2_summary,
            'business_ranking': ranking_df,
            'comparison_tables': comparison_tables,
            'attribution_results': attribution_results,
            'counter_intuitive_warnings': warnings,
            'cross_effects': cross_effects,
            'business_analysis': business_analysis,
            'analysis_params': {
                'period1': {'year': period1_year, 'months': period1_months, 'name': period1_name},
                'period2': {'year': period2_year, 'months': period2_months, 'name': period2_name},
                'uv_threshold': uv_threshold,
                'conversion_threshold': conversion_threshold
            }
        }
    
    def _log_mean(self, a, b):
        """计算对数平均"""
        if a == b:
            return a
        if a == 0 or b == 0:
            return (a + b) / 2
        return (a - b) / (np.log(a) - np.log(b))
    
    def generate_trend_data(self, year: int, months: List[int], biz_name: str,
                           start_day: Optional[int] = None, end_day: Optional[int] = None,
                           granularity: str = 'day') -> Dict:
        """
        生成趋势图数据，支持按日或按月聚合
        
        Args:
            year: 年份
            months: 月份列表
            biz_name: 业务名称
            start_day: 开始日期（可选）
            end_day: 结束日期（可选）
            granularity: 聚合粒度，'day'=按日，'month'=按月
            
        Returns:
            {
                'labels': [],      # X轴标签
                'uv_values': [],   # UV值
                'profit_values': [],  # 毛利值
                'uv_value_per_uv': []  # UV毛利价值
            }
        """
        # 构建日期范围筛选条件（与period_summary保持一致）
        if len(months) == 1:
            mask = (self.df['年'] == year) & (self.df['月'] == months[0])
            if start_day is not None:
                mask = mask & (self.df['日'] >= start_day)
            if end_day is not None:
                mask = mask & (self.df['日'] <= end_day)
        else:
            masks = []
            sorted_months = sorted(months)
            
            for i, month in enumerate(sorted_months):
                month_mask = (self.df['年'] == year) & (self.df['月'] == month)
                
                if i == 0 and start_day is not None:
                    month_mask = month_mask & (self.df['日'] >= start_day)
                elif i == len(sorted_months) - 1 and end_day is not None:
                    month_mask = month_mask & (self.df['日'] <= end_day)
                
                masks.append(month_mask)
            
            mask = masks[0]
            for m in masks[1:]:
                mask = mask | m
        
        df_period = self.df[mask].copy()
        
        if granularity == 'day':
            # 按日聚合 - 使用完整日期避免跨月份同一天被合并
            df_period['日期标签'] = df_period['年月日'].astype(str)
            grouped = df_period.groupby('日期标签').agg({
                f'{biz_name}uv': 'sum',
                f'{biz_name}毛利': 'sum',
                f'{biz_name}支付金额': 'sum',
                f'{biz_name}订单数': 'sum',
                '访问人数': 'sum'  # 添加访问人数
            }).reset_index()
            labels = grouped['日期标签'].tolist()
        elif granularity == 'week':
            # 按周聚合（v5.4新增）- 使用ISO周标准（周一为周第一天）
            df_period = df_period.sort_values('年月日').reset_index(drop=True)
            # 使用年月日的日期属性获取ISO周数和年份
            df_period['日期'] = pd.to_datetime(df_period['年月日'], format='%Y%m%d')
            df_period['ISO周'] = df_period['日期'].dt.isocalendar().week
            df_period['ISO年'] = df_period['日期'].dt.isocalendar().year
            # 创建唯一的周标识（年-周）
            df_period['周标识'] = df_period['ISO年'].astype(str) + '-W' + df_period['ISO周'].astype(str).str.zfill(2)
            
            grouped = df_period.groupby('周标识').agg({
                f'{biz_name}uv': 'sum',
                f'{biz_name}毛利': 'sum',
                f'{biz_name}支付金额': 'sum',
                f'{biz_name}订单数': 'sum',
                '访问人数': 'sum'  # 添加访问人数
            }).reset_index()
            # 按周标识排序确保顺序正确
            grouped = grouped.sort_values('周标识').reset_index(drop=True)
            # 生成连续周号标签
            labels = [f'第{i+1}周' for i in range(len(grouped))]
        elif granularity == 'month':
            # 按月聚合 - 使用已存在的'月'列
            grouped = df_period.groupby('月').agg({
                f'{biz_name}uv': 'sum',
                f'{biz_name}毛利': 'sum',
                f'{biz_name}支付金额': 'sum',
                f'{biz_name}订单数': 'sum',
                '访问人数': 'sum'  # 添加访问人数
            }).reset_index()
            # 按月份排序
            grouped = grouped.sort_values('月').reset_index(drop=True)
            labels = [f'{int(m)}月' for m in grouped['月']]
        else:
            raise ValueError(f"不支持的聚合粒度: {granularity}")
        
        uv_values = grouped[f'{biz_name}uv'].tolist()
        profit_values = grouped[f'{biz_name}毛利'].tolist()
        payment_values = grouped[f'{biz_name}支付金额'].tolist()
        order_values = grouped[f'{biz_name}订单数'].tolist()
        visitor_values = grouped['访问人数'].tolist()  # 访问人数
        
        # 计算UV毛利价值（周期合计毛利 / 周期合计UV）- 限制精度
        uv_value_per_uv = []
        for uv, profit in zip(uv_values, profit_values):
            if uv > 0:
                uv_value_per_uv.append(round(float(profit / uv), 2))  # 保留2位小数
            else:
                uv_value_per_uv.append(0.0)
        
        # 计算客单价（周期合计支付金额 / 周期合计订单数）- 限制精度
        avg_price = []
        for payment, orders in zip(payment_values, order_values):
            if orders > 0:
                avg_price.append(round(float(payment / orders), 2))  # 保留2位小数
            else:
                avg_price.append(0.0)
        
        # 计算流入率（周期合计业务UV / 周期合计访问人数）- 限制精度
        inflow_rate = []
        for uv, visitors in zip(uv_values, visitor_values):
            if visitors > 0:
                inflow_rate.append(round(float(uv / visitors * 100), 2))  # 保留2位小数
            else:
                inflow_rate.append(0.0)
        
        # 计算汇总UV毛利价值（与7维度指标表一致，用于趋势图总结）- 限制精度
        total_uv = sum(uv_values)
        total_profit = sum(profit_values)
        summary_uv_value = round(float(total_profit / total_uv), 2) if total_uv > 0 else 0.0
        
        return {
            'labels': labels,
            'uv_values': [int(round(v)) for v in uv_values],  # UV转为整数
            'profit_values': [round(float(v), 2) for v in profit_values],  # 毛利保留2位小数
            'payment_values': [round(float(v), 2) for v in payment_values],  # 支付金额保留2位小数
            'order_values': [int(round(v)) for v in order_values],  # 订单数转为整数
            'visitor_values': [int(round(v)) for v in visitor_values],  # 访问人数转为整数
            'uv_value_per_uv': uv_value_per_uv,  # UV毛利价值（已限制精度）
            'avg_price': avg_price,  # 客单价（已限制精度）
            'inflow_rate': inflow_rate,  # 流入率（已限制精度）
            'summary_uv_value': summary_uv_value,  # 汇总UV毛利价值（已限制精度）
            'total_uv': int(round(total_uv)),  # 总UV转为整数
            'total_profit': round(float(total_profit), 2),  # 总毛利保留2位小数
            'granularity': granularity
        }
    
    def full_analysis_by_date_range(self,
                                    period1_year: int,
                                    period1_months: List[int],
                                    period2_year: int,
                                    period2_months: List[int],
                                    period1_start_day: Optional[int] = None,
                                    period1_end_day: Optional[int] = None,
                                    period2_start_day: Optional[int] = None,
                                    period2_end_day: Optional[int] = None,
                                    period1_name: str = '当期',
                                    period2_name: str = '对比期',
                                    trend_granularity: str = 'day',
                                    uv_threshold: float = 2.0,
                                    conversion_threshold: float = -0.3) -> Dict:
        """
        按精确日期范围进行对比分析（增强版）
        
        支持场景：
        - 20260101-20260324 vs 20250101-20250324（跨季度）
        - 20260101-20260131 vs 20250101-20250131（单月）
        - 20260401-20260630 vs 20260101-20260331（季度对比）
        
        Args:
            period1_year: 第一个时间段年份
            period1_months: 第一个时间段月份列表
            period2_year: 第二个时间段年份
            period2_months: 第二个时间段月份列表
            period1_start_day: 第一个时间段开始日期
            period1_end_day: 第一个时间段结束日期
            period2_start_day: 第二个时间段开始日期
            period2_end_day: 第二个时间段结束日期
            period1_name: 第一个时间段名称
            period2_name: 第二个时间段名称
            trend_granularity: 趋势图聚合粒度，'day'=按日，'month'=按月
            uv_threshold: UV暴涨检测阈值
            conversion_threshold: 转化率下降阈值
        """
        print("=" * 80)
        print(f"【精确日期范围对比分析】{period1_name} vs {period2_name}")
        print(f"趋势图聚合粒度: {'按日' if trend_granularity == 'day' else '按月'}")
        print("=" * 80)
        
        # 1. 基础分析（带日期范围）
        print(f"\n[1/8] 汇总数据...")
        period1_summary = period_summary(
            self.df, period1_year, period1_months, 
            period1_start_day, period1_end_day
        )
        period2_summary = period_summary(
            self.df, period2_year, period2_months,
            period2_start_day, period2_end_day
        )
        
        # 2. 业务排序
        print(f"\n[2/8] 计算业务影响排序...")
        ranking_data = []
        for biz in BUSINESSES:
            p1_profit = period1_summary[f'{biz}毛利']
            p2_profit = period2_summary[f'{biz}毛利']
            change = p1_profit - p2_profit
            change_pct = (change / p2_profit * 100) if p2_profit > 0 else 0
            p1_share = (p1_profit / period1_summary['总毛利'] * 100) if period1_summary['总毛利'] > 0 else 0
            
            ranking_data.append({
                '业务': biz,
                f'{period1_name}毛利': p1_profit,
                f'{period2_name}毛利': p2_profit,
                '绝对变化': change,
                '变化率%': change_pct,
                f'{period1_name}毛利占比%': p1_share
            })
        
        ranking_df = pd.DataFrame(ranking_data)
        ranking_df = ranking_df.sort_values('绝对变化', ascending=False).reset_index(drop=True)
        ranking_df.index = ranking_df.index + 1
        ranking_df.index.name = '排名'
        
        # 3. 生成对比表
        print(f"\n[3/8] 生成指标对比表...")
        comparison_tables = {}
        for biz in BUSINESSES:
            comparison_data = []
            metrics = [
                ('UV', f'{biz}uv', '人'),
                ('流入率', f'{biz}流入率', '%'),
                ('转化率', f'{biz}转化率', '%'),
                ('客单价', f'{biz}客单价', '元'),
                ('毛利', f'{biz}毛利', '元'),
                ('UV毛利价值', f'{biz}uv毛利价值', '元'),
                ('毛利率', f'{biz}毛利率', '%'),
            ]
            
            for metric_name, metric_key, unit in metrics:
                p1_val = period1_summary[metric_key]
                p2_val = period2_summary[metric_key]
                
                if '率' in metric_name and metric_name != 'UV毛利价值':
                    change = p1_val - p2_val
                    change_str = f"{change:+.2f}pp"
                    direction = "上升" if change > 0 else "下降" if change < 0 else "持平"
                    p1_str = f"{p1_val:.2f}%"
                    p2_str = f"{p2_val:.2f}%"
                elif metric_name in ['UV', '毛利']:
                    # UV和毛利使用万格式
                    change = ((p1_val - p2_val) / p2_val * 100) if p2_val != 0 else 0
                    change_str = f"{change:+.2f}%"
                    direction = "增长" if change > 0 else "下降" if change < 0 else "持平"
                    p1_str = f"{p1_val/10000:.1f}万"
                    p2_str = f"{p2_val/10000:.1f}万"
                else:
                    change = ((p1_val - p2_val) / p2_val * 100) if p2_val != 0 else 0
                    change_str = f"{change:+.2f}%"
                    direction = "增长" if change > 0 else "下降" if change < 0 else "持平"
                    p1_str = f"{p1_val:,.2f}"
                    p2_str = f"{p2_val:,.2f}"
                
                # 标记异常模式
                flag = ""
                if metric_name == '转化率' and direction == "下降":
                    flag = "注意"
                elif metric_name == 'UV' and abs(change) > 100:
                    flag = "大幅波动"
                elif metric_name == '毛利率' and direction == "下降":
                    flag = "盈利下降"
                
                comparison_data.append({
                    '指标': metric_name,
                    period2_name: p2_str,
                    period1_name: p1_str,
                    '变化': change_str,
                    '方向': direction,
                    '标记': flag
                })
            
            comparison_tables[biz] = pd.DataFrame(comparison_data)
        
        # 4. 量化归因分析（使用已计算的summary数据，确保使用正确的日期范围）
        print(f"\n[4/8] 执行量化归因分析（LMDI-I无残差分解）...")
        attribution_results = {}
        for biz in BUSINESSES:
            # 直接使用period_summary的结果，确保使用正确的日期范围
            curr_uv = period1_summary[f'{biz}uv']
            prev_uv = period2_summary[f'{biz}uv']
            curr_conversion = period1_summary[f'{biz}转化率'] / 100
            prev_conversion = period2_summary[f'{biz}转化率'] / 100
            curr_price = period1_summary[f'{biz}客单价']
            prev_price = period2_summary[f'{biz}客单价']
            curr_profit = period1_summary[f'{biz}毛利']
            prev_profit = period2_summary[f'{biz}毛利']
            
            # 计算平均毛利率
            curr_orders = curr_uv * curr_conversion
            prev_orders = prev_uv * prev_conversion
            curr_margin_rate = curr_profit / (curr_orders * curr_price) if curr_orders > 0 else 0
            prev_margin_rate = prev_profit / (prev_orders * prev_price) if prev_orders > 0 else 0
            
            # LMDI-I分解
            weight = self._log_mean(curr_profit, prev_profit)
            
            contributions = {}
            if curr_uv > 0 and prev_uv > 0:
                contributions['UV变化贡献'] = weight * np.log(curr_uv / prev_uv) if curr_uv != prev_uv else 0
            else:
                contributions['UV变化贡献'] = curr_profit - prev_profit if prev_uv == 0 else 0
            
            if curr_conversion > 0 and prev_conversion > 0:
                contributions['转化率变化贡献'] = weight * np.log(curr_conversion / prev_conversion) if curr_conversion != prev_conversion else 0
            else:
                contributions['转化率变化贡献'] = 0
            
            if curr_price > 0 and prev_price > 0:
                contributions['客单价变化贡献'] = weight * np.log(curr_price / prev_price) if curr_price != prev_price else 0
            else:
                contributions['客单价变化贡献'] = 0
            
            if curr_margin_rate > 0 and prev_margin_rate > 0:
                contributions['毛利率变化贡献'] = weight * np.log(curr_margin_rate / prev_margin_rate) if curr_margin_rate != prev_margin_rate else 0
            else:
                contributions['毛利率变化贡献'] = 0
            
            total_change = curr_profit - prev_profit
            sum_contributions = sum(contributions.values())
            residual = total_change - sum_contributions
            
            # 调整残差
            if abs(residual) > 0.01 and abs(total_change) > 0.01 and sum_contributions != 0:
                adjustment_factor = total_change / sum_contributions
                for key in contributions:
                    contributions[key] *= adjustment_factor
                sum_contributions = sum(contributions.values())
                residual = total_change - sum_contributions
            
            attribution_results[biz] = {
                '业务': biz,
                f'{period1_name}毛利': curr_profit,
                f'{period2_name}毛利': prev_profit,
                '总变化': total_change,
                **contributions,
                '残差': residual,
                '验证总和': sum_contributions,
                '基础数据': {
                    'UV': {'当期': curr_uv, '对比期': prev_uv, '变化率': (curr_uv/prev_uv-1)*100 if prev_uv > 0 else 0},
                    '转化率': {'当期': curr_conversion*100, '对比期': prev_conversion*100, '变化pp': (curr_conversion-prev_conversion)*100},
                    '客单价': {'当期': curr_price, '对比期': prev_price, '变化率': (curr_price/prev_price-1)*100 if prev_price > 0 else 0},
                    '毛利率': {'当期': curr_margin_rate*100, '对比期': prev_margin_rate*100, '变化pp': (curr_margin_rate-prev_margin_rate)*100},
                }
            }
        
        # 5. 反直觉模式检测
        print(f"\n[5/8] 检测反直觉模式...")
        warnings = []
        for biz in BUSINESSES:
            uv_change = (period1_summary[f'{biz}uv'] - period2_summary[f'{biz}uv']) / period2_summary[f'{biz}uv'] if period2_summary[f'{biz}uv'] > 0 else 0
            conversion_change = period1_summary[f'{biz}转化率'] - period2_summary[f'{biz}转化率']
            
            if uv_change > uv_threshold and conversion_change < conversion_threshold:
                warnings.append({
                    '业务': biz,
                    '模式': 'UV暴涨但转化率下降',
                    '严重程度': '高' if uv_change > 3.0 else '中',
                    '说明': f'UV增长{uv_change*100:.0f}%，但转化率下降{abs(conversion_change):.2f}pp',
                    '根因': '流量增长伴随质量稀释，可能原因：1)新流量渠道质量较低 2)页面体验下降 3)促销活动吸引非目标用户',
                    '建议': '1)分析新流量来源质量 2)优化落地页体验 3)精准定位目标用户'
                })
        
        # 6. 交叉效应分析
        print(f"\n[6/8] 分析UV-转化率交叉效应...")
        cross_effects = {}
        for biz in BUSINESSES:
            uv_change = (period1_summary[f'{biz}uv'] - period2_summary[f'{biz}uv']) / period2_summary[f'{biz}uv'] if period2_summary[f'{biz}uv'] > 0 else 0
            conversion_change = period1_summary[f'{biz}转化率'] - period2_summary[f'{biz}转化率']
            
            if uv_change > 0.5 and conversion_change < -0.2:
                effect_type = '负相关'
                description = 'UV大幅增长伴随转化率显著下降，存在明显的流量质量稀释效应'
            elif uv_change > 0.5 and conversion_change > 0:
                effect_type = '正相关'
                description = 'UV增长同时转化率提升，流量质量与规模同步改善'
            elif abs(uv_change) < 0.1 and abs(conversion_change) > 0.3:
                effect_type = '纯效率驱动'
                description = 'UV稳定，转化率大幅变化，增长完全由效率提升驱动'
            else:
                effect_type = '弱相关'
                description = 'UV和转化率变化无明显相关性'
            
            cross_effects[biz] = {
                '效应类型': effect_type,
                '描述': description,
                'UV变化': uv_change,
                '转化率变化': conversion_change,
                '相关性强度': abs(uv_change * conversion_change)
            }
        
        # 7. 业务分析总结（v6.1：严格四段结构，结合LMDI归因，含横向比较验证）
        print(f"\n[7/8] 生成业务分析总结（v6.1 深度四段结构）...")
        import statistics as _stats

        # ── 横向排序基准（供跨业务比较使用，避免凭感觉断言）──────────
        _uvval_rank   = sorted(BUSINESSES, key=lambda b: period1_summary[f'{b}uv毛利价值'])
        _price_rank   = sorted(BUSINESSES, key=lambda b: period1_summary[f'{b}客单价'])
        _conv_rank    = sorted(BUSINESSES, key=lambda b: period1_summary[f'{b}转化率'])
        _uv_rank      = sorted(BUSINESSES, key=lambda b: period1_summary[f'{b}uv'])
        _profit_share = sorted(BUSINESSES, key=lambda b: period1_summary[f'{b}毛利'] / period1_summary['总毛利'])
        _uvval_median = _stats.median([period1_summary[f'{b}uv毛利价值'] for b in BUSINESSES])

        def _rank_label(lst, biz):
            """返回业务在升序列表中的排名描述"""
            idx = lst.index(biz)
            n   = len(lst)
            if idx == 0:      return '全场最低'
            if idx == n - 1:  return '全场最高'
            if idx == n - 2:  return '全场第二高'
            return f'全场第{idx+1}低'

        business_analysis = {}
        for biz in BUSINESSES:
            p1  = period1_summary
            p2  = period2_summary
            days = int(p1['天数'])

            profit1 = p1[f'{biz}毛利'];       profit2 = p2[f'{biz}毛利']
            uv1     = p1[f'{biz}uv'];          uv2     = p2[f'{biz}uv']
            conv1   = p1[f'{biz}转化率'];      conv2   = p2[f'{biz}转化率']
            price1  = p1[f'{biz}客单价'];      price2  = p2[f'{biz}客单价']
            uvval1  = p1[f'{biz}uv毛利价值'];  uvval2  = p2[f'{biz}uv毛利价值']
            margin1 = p1[f'{biz}毛利率'];      margin2 = p2[f'{biz}毛利率']
            inflow1 = p1[f'{biz}流入率'];      inflow2 = p2[f'{biz}流入率']

            profit_chg_pct  = (profit1 - profit2) / profit2 * 100 if profit2 else 0
            uv_chg_pct      = (uv1 - uv2) / uv2 * 100 if uv2 else 0
            conv_chg        = conv1 - conv2
            price_chg_pct   = (price1 - price2) / price2 * 100 if price2 else 0
            uvval_chg_pct   = (uvval1 - uvval2) / uvval2 * 100 if uvval2 else 0
            margin_chg      = margin1 - margin2
            daily_profit    = profit1 / days / 10000

            # LMDI数据
            attr      = attribution_results.get(biz, {})
            lmdi_uv   = attr.get('UV变化贡献', 0)
            lmdi_conv = attr.get('转化率变化贡献', 0)
            lmdi_prc  = attr.get('客单价变化贡献', 0)
            lmdi_marg = attr.get('毛利率变化贡献', 0)
            lmdi_tot  = attr.get('总变化', profit1 - profit2)

            # 找LMDI最大贡献因子
            lmdi_map = {'UV': lmdi_uv, '转化率': lmdi_conv, '客单价': lmdi_prc, '毛利率': lmdi_marg}
            if profit_chg_pct > 0:
                main_driver = max(lmdi_map, key=lambda k: lmdi_map[k])
                main_driver_val = lmdi_map[main_driver]
            else:
                main_driver = min(lmdi_map, key=lambda k: lmdi_map[k])
                main_driver_val = lmdi_map[main_driver]

            # 横向比较标签
            uvval_rank_lbl  = _rank_label(_uvval_rank,  biz)
            price_rank_lbl  = _rank_label(_price_rank,  biz)
            conv_rank_lbl   = _rank_label(_conv_rank,   biz)

            # ── 趋势判断
            if   profit_chg_pct > 30:  trend = '爆发式增长'
            elif profit_chg_pct > 10:  trend = '稳健增长'
            elif profit_chg_pct > 0:   trend = '微增'
            elif profit_chg_pct > -5:  trend = '微降'
            elif profit_chg_pct > -10: trend = '明显下滑'
            else:                       trend = '大幅下滑'

            # ── 第①段：一句话定性 ────────────────────────────────────
            if profit_chg_pct > 50:
                seg1 = f'{biz}正处于<strong>爆发式起量阶段，流量增长真实，但变现能力尚未跟上规模</strong>。'
            elif profit_chg_pct > 20:
                seg1 = f'{biz}呈现<strong>高速健康增长态势</strong>，增速{profit_chg_pct:+.1f}%是本期最强劲的增长业务之一。'
            elif profit_chg_pct > 10:
                if price_chg_pct > 3 and uvval_chg_pct > 0:
                    seg1 = f'{biz}是本期<strong>质量最高的成熟业务，展现了"提价不失量"的高质量增长模式</strong>。'
                elif uv_chg_pct < -2:
                    seg1 = f'{biz}是本期<strong>"效率驱动型"增长的典型，在流量走弱的逆境中实现了结构升级</strong>。'
                else:
                    seg1 = f'{biz}实现<strong>稳健增长（{profit_chg_pct:+.1f}%）</strong>，量质双升格局基本确立。'
            elif profit_chg_pct > 0:
                seg1 = f'{biz}增速温和（{profit_chg_pct:+.1f}%），整体趋势向好但<strong>动能有限，需排查是否有指标在悄悄恶化</strong>。'
            elif profit_chg_pct > -5:
                seg1 = f'{biz}出现<strong>轻微下滑（{profit_chg_pct:.1f}%），需警惕多指标是否同向恶化形成周期性拐点</strong>。'
            elif profit_chg_pct > -10:
                seg1 = f'{biz}出现<strong>明显下滑（{profit_chg_pct:.1f}%）</strong>，变现能力在退化，需优先排查核心根因。'
            else:
                # 下滑超10%：判断是"不来了"还是"来了不买"
                if uv_chg_pct < -5:
                    seg1 = f'{biz}遭遇<strong>大幅下滑（{profit_chg_pct:.1f}%），以流量萎缩为主因——用户"不来了"</strong>。'
                else:
                    seg1 = f'{biz}出现了本期<strong>最典型的"来了不买"模式</strong>：UV尚在，但变现能力全面退化。'

            # ── 第②段：核心驱动逻辑（结合LMDI）────────────────────────
            # 按贡献绝对值排序，找前2个因子
            lmdi_sorted = sorted(lmdi_map.items(), key=lambda kv: abs(kv[1]), reverse=True)
            f1_name, f1_val = lmdi_sorted[0]
            f2_name, f2_val = lmdi_sorted[1]

            def _factor_desc(name, val, biz_ctx):
                sign = '+' if val >= 0 else ''
                v_wan = val / 10000
                if   name == 'UV':    return f'UV变化贡献{sign}{v_wan:.2f}万'
                elif name == '转化率': return f'转化率变化贡献{sign}{v_wan:.2f}万'
                elif name == '客单价': return f'客单价变化贡献{sign}{v_wan:.2f}万'
                else:                  return f'毛利率变化贡献{sign}{v_wan:.2f}万'

            if profit_chg_pct > 0:
                # 增长：解释"为什么增"
                seg2 = (f'LMDI归因显示，{_factor_desc(f1_name, f1_val, biz)}（占增量'
                        f'{abs(f1_val/lmdi_tot*100):.1f}%）是最大驱动力，'
                        f'{_factor_desc(f2_name, f2_val, biz)}为第二驱动因子。')
                # 补充异常因子说明
                neg_factors = [(n, v) for n, v in lmdi_map.items() if v < -0.5 * abs(lmdi_tot) / 4]
                if neg_factors:
                    nf_name, nf_val = max(neg_factors, key=lambda kv: abs(kv[1]))
                    seg2 += f'值得注意的是，{nf_name}产生了{nf_val/10000:.2f}万的负向拖累，是潜在风险点。'
            else:
                # 下滑：解释"为什么跌"
                neg_lmdi = [(n, v) for n, v in lmdi_map.items() if v < 0]
                neg_lmdi_sorted = sorted(neg_lmdi, key=lambda kv: kv[1])
                if neg_lmdi_sorted:
                    main_neg_name, main_neg_val = neg_lmdi_sorted[0]
                    seg2 = (f'LMDI归因揭示了下滑结构：{_factor_desc(main_neg_name, main_neg_val, biz)}'
                            f'（占跌幅{abs(main_neg_val/lmdi_tot*100):.1f}%）是最大拖累。')
                    if len(neg_lmdi_sorted) >= 2:
                        n2, v2 = neg_lmdi_sorted[1]
                        seg2 += f'{_factor_desc(n2, v2, biz)}构成双重下行压力。'
                    # 有正向但不够抵消
                    pos_factors = [(n, v) for n, v in lmdi_map.items() if v > 0]
                    if pos_factors:
                        pf_name, pf_val = max(pos_factors, key=lambda kv: kv[1])
                        seg2 += f'{pf_name}贡献了{pf_val/10000:.2f}万的正向缓冲，但不足以扭转整体。'
                else:
                    seg2 = f'LMDI归因显示各因子均有负向贡献，{biz}业务面临全面下行压力。'

            # ── 第③段：关键信号（亮点或风险，必须有数字+临界值）────────
            if profit_chg_pct > 0:
                # 正增长：找最值得关注的亮点或潜在风险
                if profit_chg_pct > 50 and uvval1 < _uvval_median:
                    seg3 = (f'<strong>最值得关注的信号：</strong>UV毛利价值¥{uvval1:.2f}（{uvval_rank_lbl}，全场中位数¥{_uvval_median:.2f}），'
                            f'规模扩张的同时变现效率远未跟上。若UV毛利价值突破¥{_uvval_median:.2f}，才意味着变现进入良性轨道；'
                            f'若停滞在¥{uvval1*0.8:.2f}附近，需警惕增长天花板。')
                elif conv_chg < -0.1 and price_chg_pct > 3:
                    seg3 = (f'<strong>最值得关注的信号：</strong>客单价从¥{price2:.2f}提升至¥{price1:.2f}（+{price_chg_pct:.1f}%），'
                            f'但转化率从{conv2:.2f}%跌至{conv1:.2f}%（{conv_chg:.2f}pp）——价格敏感用户开始流失的早期信号。'
                            f'建议以{conv1-0.3:.2f}%作为转化率预警阈值；若跌破，需评估是否放缓提价节奏。')
                elif uv_chg_pct < -3 and conv_chg > 0.2:
                    seg3 = (f'<strong>最值得关注的信号：</strong>转化率{conv2:.2f}%→{conv1:.2f}%（+{conv_chg:.2f}pp），'
                            f'UV却从{uv2/10000:.1f}万降至{uv1/10000:.1f}万（{uv_chg_pct:.1f}%）。'
                            f'依赖效率提升的增长路径有天花板，转化率继续大幅提升的空间有限，'
                            f'一旦效率红利收窄，UV持续下滑将成主要拖累。')
                elif price_chg_pct < -5 and conv_chg > 0:
                    seg3 = (f'<strong>最值得关注的信号：</strong>客单价已从¥{price2:.2f}下滑至¥{price1:.2f}（{price_chg_pct:.1f}%），'
                            f'转化率{conv1:.2f}%虽在提升，但需明确：是产品体验变好，还是降价让价格敏感用户买单？'
                            f'若是后者，建议以¥{price1*0.95:.0f}作为客单价底线预警。')
                else:
                    seg3 = (f'<strong>最值得关注的信号：</strong>UV毛利价值¥{uvval1:.2f}（{uvval_rank_lbl}），'
                            f'{"高于" if uvval1 >= _uvval_median else "低于"}全场中位数¥{_uvval_median:.2f}。'
                            f'当前增长{"质量较高，需持续维持变现效率" if uvval1 >= _uvval_median else "存在效率提升空间，需防止规模稀释单位价值"}。')
            else:
                # 下滑：找最核心的风险数字
                if uv_chg_pct > 5 and profit_chg_pct < -5:
                    seg3 = (f'<strong>最值得关注的信号：</strong>UV增长{uv_chg_pct:.1f}%但毛利跌{abs(profit_chg_pct):.1f}%，'
                            f'UV毛利价值从¥{uvval2:.2f}骤降至¥{uvval1:.2f}（{uvval_chg_pct:.1f}%）——'
                            f'<strong>新引入的流量与目标用户画像严重不匹配</strong>，进来的用户购买意愿更低、购买金额更少。'
                            f'首要任务不是继续拉UV，而是搞清楚新增UV从哪里来，砍掉低质渠道。')
                elif price_chg_pct < -10:
                    seg3 = (f'<strong>最值得关注的信号：</strong>客单价从¥{price2:.2f}暴跌至¥{price1:.2f}（{price_chg_pct:.1f}%），'
                            f'是本期跌幅最为显著的变现指标。如此大的跌幅通常不是自然发生的——'
                            f'需第一时间确认：是主动降价促销、产品结构变化，还是用户结构变化？三种根因对应完全不同的应对策略。')
                elif conv_chg < -0.1 and price_chg_pct < -3:
                    seg3 = (f'<strong>最值得关注的信号：</strong>转化率{conv2:.2f}%→{conv1:.2f}%（{conv_chg:.2f}pp）'
                            f'与客单价{price2:.2f}→{price1:.2f}（{price_chg_pct:.1f}%）同步恶化，'
                            f'属于双重变现压力。UV毛利价值¥{uvval1:.2f}已较去年跌{abs(uvval_chg_pct):.1f}%，'
                            f'若继续下滑至¥{uvval1*0.85:.2f}，将触发业务萎缩的不可逆阈值。')
                else:
                    seg3 = (f'<strong>最值得关注的信号：</strong>UV毛利价值¥{uvval1:.2f}（{uvval_rank_lbl}），'
                            f'同比跌{abs(uvval_chg_pct):.1f}%，若继续下滑至¥{uvval1*0.85:.2f}以下，'
                            f'将使业务在总毛利盘中的贡献进一步边缘化。')

            # ── 第④段：前瞻判断 ──────────────────────────────────────
            if profit_chg_pct > 50:
                seg4 = (f'<strong>前瞻判断：</strong>{biz}是典型"流量先行、变现滞后"形态。'
                        f'若未来UV毛利价值能从¥{uvval1:.2f}突破¥{_uvval_median:.2f}（全场中位数），'
                        f'意味着变现能力开始匹配规模，进入良性轨道；'
                        f'若UV继续高增而UV毛利价值停滞，需警惕流量天花板到来后的增长乏力。')
            elif profit_chg_pct > 20:
                roi_target = profit1 / days / 10000 * 1.1
                seg4 = (f'<strong>前瞻判断：</strong>当前增长模式健康且可持续，'
                        f'建议重点维持{f1_name}的正向动能。'
                        f'若{f1_name}优势继续保持，下一周期日均毛利有望达到¥{roi_target:.2f}万。'
                        f'需预防{"转化率继续下滑" if conv_chg < 0 else "客单价回调"}对增长的侵蚀。')
            elif profit_chg_pct > 0:
                if price_chg_pct < -5 and conv_chg > 0:
                    seg4 = (f'<strong>前瞻判断：</strong>目前处于"增长但变现效率走弱"的危险状态。'
                            f'建议尽快明确客单价下滑原因，设置¥{price1*0.95:.0f}为价格底线预警。'
                            f'如果确认是定价策略问题，需要在转化率和客单价之间找到更优平衡点。')
                else:
                    seg4 = (f'<strong>前瞻判断：</strong>动能温和，短期内维持现状概率较高。'
                            f'若希望加速增长，需针对{main_driver}做专项提升；'
                            f'若{"UV" if uv_chg_pct < 0 else "转化率"}持续走弱，可能在下一周期转为负增长。')
            elif profit_chg_pct > -5:
                seg4 = (f'<strong>前瞻判断：</strong>轻微下滑阶段，核心问题是{"转化率" if conv_chg < -0.05 else "客单价"}持续走弱。'
                        f'若不干预，按当前趋势，下一周期毛利下滑幅度可能扩大至{abs(profit_chg_pct)*1.5:.1f}%以上。'
                        f'3-5个正向信号中需出现1-2个逆转，才能阻止业务进入持续下行通道。')
            else:
                seg4 = (f'<strong>前瞻判断：</strong>下滑{abs(profit_chg_pct):.1f}%已是本期显著负面信号。'
                        f'若不干预，UV毛利价值¥{uvval1:.2f}可能继续走低，'
                        f'单凭{"规模" if uv_chg_pct > 0 else "现有效率"}无法对冲变现退化。'
                        f'建议将{biz}业务列为P0优先干预，在30天内给出根因报告。')

            evaluation = f'{seg1}\n\n{seg2}\n\n{seg3}\n\n{seg4}'

            # 构建驱动因素列表（保留原有结构，供其他地方使用）
            drivers = []
            if uv_chg_pct > 5:
                drivers.append(f"UV从{uv2/10000:.1f}万→{uv1/10000:.1f}万（+{uv_chg_pct:.1f}%）")
            if conv_chg > 0.1:
                drivers.append(f"转化率{conv2:.2f}%→{conv1:.2f}%（+{conv_chg:.2f}pp）")
            if price_chg_pct > 3:
                drivers.append(f"客单价¥{price2:.2f}→¥{price1:.2f}（+{price_chg_pct:.1f}%）")
            if uvval_chg_pct > 5:
                drivers.append(f"UV毛利价值¥{uvval2:.2f}→¥{uvval1:.2f}（+{uvval_chg_pct:.1f}%）")

            challenges = []
            if uv_chg_pct < -5:
                challenges.append(f"UV从{uv2/10000:.1f}万→{uv1/10000:.1f}万（{uv_chg_pct:.1f}%）")
            if conv_chg < -0.1:
                challenges.append(f"转化率{conv2:.2f}%→{conv1:.2f}%（{conv_chg:.2f}pp）")
            if price_chg_pct < -3:
                challenges.append(f"客单价¥{price2:.2f}→¥{price1:.2f}（{price_chg_pct:.1f}%）")
            if uvval_chg_pct < -5:
                challenges.append(f"UV毛利价值¥{uvval2:.2f}→¥{uvval1:.2f}（{uvval_chg_pct:.1f}%）")

            business_analysis[biz] = {
                '趋势': trend,
                '驱动因素': drivers,
                '挑战': challenges,
                '综合评价': evaluation,
                # 附加结构化数据，供generate_report.py战略建议使用
                '_metrics': {
                    'profit_chg_pct': profit_chg_pct,
                    'uv_chg_pct': uv_chg_pct,
                    'conv_chg': conv_chg,
                    'price_chg_pct': price_chg_pct,
                    'uvval_chg_pct': uvval_chg_pct,
                    'margin_chg': margin_chg,
                    'daily_profit': daily_profit,
                    'lmdi_uv': lmdi_uv, 'lmdi_conv': lmdi_conv,
                    'lmdi_prc': lmdi_prc, 'lmdi_marg': lmdi_marg,
                    'main_driver': main_driver,
                    'uvval1': uvval1, 'uvval2': uvval2,
                    'price1': price1, 'price2': price2,
                    'conv1': conv1,   'conv2': conv2,
                    'uv1': uv1,       'uv2': uv2,
                    'profit1': profit1, 'profit2': profit2,
                    'uvval_median': _uvval_median,
                    'uvval_rank': _uvval_rank.index(biz),
                    'price_rank': _price_rank.index(biz),
                    'conv_rank': _conv_rank.index(biz),
                }
            }
        
        # 8. 生成趋势图数据 - 同时生成日、周、月三种粒度数据（修复周/月聚合问题）
        print(f"\n[8/8] 生成趋势图数据（日、周、月三种粒度）...")
        trend_data = {}
        trend_summaries = {}
        for biz in BUSINESSES:
            # 同时生成日、周、月三种粒度的数据
            trend_data[biz] = {
                'period1': {
                    'day': self.generate_trend_data(
                        period1_year, period1_months, biz,
                        period1_start_day, period1_end_day, 'day'
                    ),
                    'week': self.generate_trend_data(
                        period1_year, period1_months, biz,
                        period1_start_day, period1_end_day, 'week'
                    ),
                    'month': self.generate_trend_data(
                        period1_year, period1_months, biz,
                        period1_start_day, period1_end_day, 'month'
                    )
                },
                'period2': {
                    'day': self.generate_trend_data(
                        period2_year, period2_months, biz,
                        period2_start_day, period2_end_day, 'day'
                    ),
                    'week': self.generate_trend_data(
                        period2_year, period2_months, biz,
                        period2_start_day, period2_end_day, 'week'
                    ),
                    'month': self.generate_trend_data(
                        period2_year, period2_months, biz,
                        period2_start_day, period2_end_day, 'month'
                    )
                }
            }
            
            # 生成趋势概况摘要（v5.4新增）- 修复：从day粒度获取数据
            p1_day_data = trend_data[biz]['period1']['day']
            p2_day_data = trend_data[biz]['period2']['day']
            
            # 计算平均值用于概况
            avg_profit_p1 = sum(p1_day_data.get('profit_values', [])) / len(p1_day_data.get('profit_values', [1])) if p1_day_data.get('profit_values') else 0
            avg_profit_p2 = sum(p2_day_data.get('profit_values', [])) / len(p2_day_data.get('profit_values', [1])) if p2_day_data.get('profit_values') else 0
            avg_uv_p1 = sum(p1_day_data.get('uv_values', [])) / len(p1_day_data.get('uv_values', [1])) if p1_day_data.get('uv_values') else 0
            avg_uv_p2 = sum(p2_day_data.get('uv_values', [])) / len(p2_day_data.get('uv_values', [1])) if p2_day_data.get('uv_values') else 0
            avg_value_p1 = sum(p1_day_data.get('uv_value_per_uv', [])) / len(p1_day_data.get('uv_value_per_uv', [1])) if p1_day_data.get('uv_value_per_uv') else 0
            avg_value_p2 = sum(p2_day_data.get('uv_value_per_uv', [])) / len(p2_day_data.get('uv_value_per_uv', [1])) if p2_day_data.get('uv_value_per_uv') else 0
            avg_price_p1 = sum(p1_day_data.get('avg_price', [])) / len(p1_day_data.get('avg_price', [1])) if p1_day_data.get('avg_price') else 0
            avg_price_p2 = sum(p2_day_data.get('avg_price', [])) / len(p2_day_data.get('avg_price', [1])) if p2_day_data.get('avg_price') else 0
            avg_inflow_p1 = sum(p1_day_data.get('inflow_rate', [])) / len(p1_day_data.get('inflow_rate', [1])) if p1_day_data.get('inflow_rate') else 0
            avg_inflow_p2 = sum(p2_day_data.get('inflow_rate', [])) / len(p2_day_data.get('inflow_rate', [1])) if p2_day_data.get('inflow_rate') else 0
            
            profit_change = ((avg_profit_p1 - avg_profit_p2) / avg_profit_p2 * 100) if avg_profit_p2 > 0 else 0
            uv_change = ((avg_uv_p1 - avg_uv_p2) / avg_uv_p2 * 100) if avg_uv_p2 > 0 else 0
            value_change = ((avg_value_p1 - avg_value_p2) / avg_value_p2 * 100) if avg_value_p2 > 0 else 0
            price_change = ((avg_price_p1 - avg_price_p2) / avg_price_p2 * 100) if avg_price_p2 > 0 else 0
            inflow_change = avg_inflow_p1 - avg_inflow_p2
            
            trend_summaries[biz] = {
                'profit': f'{period1_name}日均毛利{"增长" if profit_change > 0 else "下降"}{abs(profit_change):.1f}%，{"整体呈上升趋势" if profit_change > 0 else "整体呈下降趋势"}。',
                'uv': f'{period1_name}日均UV{"增长" if uv_change > 0 else "下降"}{abs(uv_change):.1f}%，流量{"持续扩大" if uv_change > 0 else "有所收缩"}。',
                'value': f'{period1_name}UV变现效率{"提升" if value_change > 0 else "下降"}{abs(value_change):.1f}%，{"变现能力增强" if value_change > 0 else "需关注变现效率"}。',
                'price': f'{period1_name}客单价{"提升" if price_change > 0 else "下降"}{abs(price_change):.1f}%，{"价格策略有效" if price_change > 0 else "需调整价格策略"}。',
                'inflow': f'{period1_name}流入率{"提升" if inflow_change > 0 else "下降"}{abs(inflow_change):.2f}pp，{"入口吸引力增强" if inflow_change > 0 else "需优化流量入口"}。',
                'comprehensive': f'{biz}业务整体{"表现良好" if profit_change > 0 else "面临挑战"}，建议{"持续优化" if profit_change > 0 else "深入分析原因并制定改进方案"}。'
            }
        
        print("\n" + "=" * 80)
        print("【精确日期范围对比分析】执行完成")
        print("=" * 80)
        
        return {
            'current_summary': period1_summary,
            'previous_summary': period2_summary,
            'business_ranking': ranking_df,
            'comparison_tables': comparison_tables,
            'attribution_results': attribution_results,
            'counter_intuitive_warnings': warnings,
            'cross_effects': cross_effects,
            'business_analysis': business_analysis,
            'trend_data': trend_data,
            'trend_summaries': trend_summaries,
            'analysis_params': {
                'period1': {
                    'year': period1_year, 
                    'months': period1_months,
                    'start_day': period1_start_day,
                    'end_day': period1_end_day,
                    'name': period1_name
                },
                'period2': {
                    'year': period2_year, 
                    'months': period2_months,
                    'start_day': period2_start_day,
                    'end_day': period2_end_day,
                    'name': period2_name
                },
                'trend_granularity': trend_granularity,
                'uv_threshold': uv_threshold,
                'conversion_threshold': conversion_threshold
            }
        }


if __name__ == '__main__':
    # 示例用法
    file_path = '增值业务流量转化明细表.xlsx'
    
    print("=" * 80)
    print("流量分析示例")
    print("=" * 80)
    
    # 初始化分析器
    analyzer = TrafficAnalysis(file_path)
    
    # 执行完整分析
    results = analyzer.full_analysis_ultimate(
        current_year=2025,
        months=[1, 2],
        previous_year=2024,
        enable_mom=True,
        uv_threshold=2.0,  # UV增长200%触发警告
        conversion_threshold=-0.3  # 转化率下降0.3pp触发警告
    )
    
    # 打印高速宝的对比表
    print("\n=== 高速宝指标对比表 ===")
    print(results['comparison_tables']['高速宝'].to_string(index=False))
    
    # 打印高速宝的归因分析
    print("\n=== 高速宝毛利变化归因（LMDI-I无残差）===")
    attr = results['attribution_results']['高速宝']
    print(f"总变化: ¥{attr['总变化']:,.2f}")
    print(f"UV贡献: ¥{attr['UV变化贡献']:,.2f}")
    print(f"转化率贡献: ¥{attr['转化率变化贡献']:,.2f}")
    print(f"客单价贡献: ¥{attr['客单价变化贡献']:,.2f}")
    print(f"毛利率贡献: ¥{attr['毛利率变化贡献']:,.2f}")
    print(f"残差: ¥{attr['残差']:.4f}（应接近0）")
    
    # 打印交叉效应
    print("\n=== UV-转化率交叉效应分析 ===")
    for biz, effect in results['cross_effects'].items():
        print(f"{biz}: {effect['效应类型']} - {effect['描述'][:30]}...")
