# 增值业务流量分析专家 - v6.0

## 核心功能

- **7维度指标对比**（UV/流入率/转化率/客单价/毛利/UV毛利价值/毛利率）
- **LMDI-I无残差归因**（4因子+可视化条形）
- **反直觉模式检测**（系统自动+人工两层）
- **5趋势图**（毛利/UV/UV价值/客单价/流入率）+ 日/周/月切换
- **深度综合评价**（强制四段结构：定性→驱动逻辑→关键信号→前瞻判断）
- **业务健康度矩阵**（毛利增长率×毛利占比，中位数分界，含象限迁移分析）
- **战略建议4卡片**（止损/修复/放大/复制，含量化ROI）
- **行动计划P0/P1/P2**（5列表格，含验收标准）
- **整体洞察4维度**（含穿透性总结判断）
- **HTML报告**（Fathom科学期刊美学）

## 文件结构

```
增值业务流量分析专家/
├── SKILL.md              # 主技能文档（15节完整规范）
├── USAGE.md              # 使用话术 + 输出质量自查
├── README.md             # 本文件
├── CHANGELOG.md          # 版本历史
├── generate_report.py    # ★ 标准报告生成脚本（唯一正确的生成入口）
├── cases/
│   └── 报告案例.html      # 高质量参考样本（所有新报告以此为质量基准）
└── scripts/
    └── analysis_core.py  # 核心分析脚本（数据加载+LMDI+趋势图）
```

## 快速使用

```python
from scripts.analysis_core import TrafficAnalysis
from generate_report import generate_html_report

analyzer = TrafficAnalysis('增值业务流量转化明细表.xlsx')
results  = analyzer.full_analysis_by_date_range(
    period1_year=2026, period1_months=[1,2,3],
    period1_start_day=1, period1_end_day=25,
    period2_year=2025, period2_months=[1,2,3],
    period2_start_day=1, period2_end_day=25,
    period1_name='2026年', period2_name='2025年'
)
generate_html_report(results, output_path='增值业务流量分析报告_2026年.html')
```

话术触发方式见 `USAGE.md`。

## 版本历史

- **v6.0** (2026-03-31): 标准化生成脚本版——新增 `generate_report.py`，将报告案例完整生成逻辑固化，废弃旧版 html_generator.py
- **v5.9** (2026-03-31): 质量标准全面固化版——HTML样式规范、趋势图概况规范、反直觉两层检测
- **v5.8** (2026-03-31): 整体洞察4维度写作规范
- **v5.7** (2026-03-31): 战略建议+行动计划写作规范
- **v5.6** (2026-03-31): 深度综合评价四段结构+业务健康度矩阵方案A
